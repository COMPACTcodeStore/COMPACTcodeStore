function [newM,barrayX,barrayY] = fft_based_Xcorr2(m)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
m_process=m-mean(m(:));
N_slice=size(m,3);

x=linspace(pi,-pi, size(m,2)+1);x(1)=[];
y=linspace(pi,-pi, size(m,1)+1);y(1)=[];
[X,Y]=meshgrid(x,y);
% b=zeros(N_slice,2);
% bNumber=0;
barrayY=[];
barrayX=[];
% bNumber=0;
xcorr2R=200;% test 10 is fine for bead data
CcenterR=xcorr2R-1;
Czoom=1;% odd number;
% find the correlation origin pixel number;

% C=xcorr2Limit(m(:,:,1),m(:,:,1),xcorr2R);
C=xcorr2_fft(m_process(:,:,1),m_process(:,:,1));
C=C(size(m,1)-xcorr2R:size(m,1)+xcorr2R,size(m,2)-xcorr2R:size(m,2)+xcorr2R);
Cf=fftshift(fft2(C));
Cfexpand=padarray(Cf, (Czoom-1)/2*[2*CcenterR+1, 2*CcenterR+1]);
Cnew=ifft2(ifftshift(Cfexpand));
[value,id] = max(Cnew(:));
[cy0,cx0] = ind2sub(size(Cnew),id);
for k1=1:N_slice-1
    disp(k1);
    
    %C=xcorr2(mshift(:,:,k1),mshift(:,:,k2));
    %C=C(size(m,1)-CcenterR:size(m,1)+CcenterR, size(m,2)-CcenterR:size(m,2)+CcenterR);
    %        C=xcorr2Limit(m(:,:,k1),m(:,:,k2),xcorr2R);
    C=xcorr2_fft(m_process(:,:,k1+1),m_process(:,:,1));
    C=C(size(m,1)-xcorr2R:size(m,1)+xcorr2R,size(m,2)-xcorr2R:size(m,2)+xcorr2R);
    Cf=fftshift(fft2(C));
    Cfexpand=padarray(Cf, (Czoom-1)/2*[2*CcenterR+1, 2*CcenterR+1]);
    Cnew=ifft2(ifftshift(Cfexpand));
    [value,id] = max(Cnew(:));
    [cy,cx] = ind2sub(size(Cnew),id);
%     b(k1,1)=(cy0-cy)/Czoom;
%     b(k1,2)=(cx0-cx)/Czoom;
%     bNumber=bNumber+1;
    barrayY=[barrayY; (cy0-cy)/Czoom];
    barrayX=[barrayX; (cx0-cx)/Czoom];
    
end

px=-1*barrayX;
py=-1*barrayY;
newM= m.*0;
newM(:,:,1)=m(:,:,1);
for k=1:N_slice-1
    d=fftshift(fft2(m(:,:,k+1))).*exp(1i*X*-px(k)).*exp(1i*Y*-py(k));
    newM(:,:,k+1)=abs(ifft2(ifftshift(d)));
end

end
