%% Analysis trace from raw data, created by Yiyong Han, 20181219
clear all;
close all;
clc;
% read excel
framerate=0.72;
Time_interval=10; % for figure plot, unit in second
% xlsfoldername='J:\cell ablation\CROSS\20180827 G6S SR101\test\twochannels\1';
% xlsfilename='1.xls';

[xlsfilename,xlsfoldername,FilterIndexsigMat] = uigetfile({'*.xls'});
xlsfoldername=xlsfoldername(1:end-1);

mkdir([xlsfoldername '\Processing'])
mkdir([xlsfoldername '\Processing\Normilzed sequence'])
mkdir([xlsfoldername '\Processing\Real sequence'])
mkdir([xlsfoldername '\Processing\Plot sequence'])
mkdir([xlsfoldername '\Processing\Single cell plot'])
mkdir([xlsfoldername '\Processing\Trace plot'])
mkdir([xlsfoldername '\Processing\Trace analysis'])
mkdir([xlsfoldername '\Processing\dFF'])
mkdir([xlsfoldername '\Processing\dFF\pdf'])
mkdir([xlsfoldername '\Processing\dFF\jpg'])

xlsData_ori = importdata([xlsfoldername '\' xlsfilename]);
N_sheets=length(fieldnames(xlsData_ori));
Name_sheets=fieldnames(xlsData_ori);
xlsData=struct2cell(xlsData_ori);
N_frames=size(xlsData{1},1);
N_cell=size(xlsData{1},2)-1;
xvector=(0:N_frames-1)/framerate;
disp('Read xls file done!!')

%% search for rest or run AND get delta F/F for running and rest
Index = strfind(Name_sheets, 'est');
for ii=1:N_sheets
    
    aa=find(~isempty(Index{ii}));
    if aa==1
        restindex(ii)=1;
    else
        restindex(ii)=0;
    end
end
runindex=1-restindex;
restid=find(restindex==1);

% get rawdata
for ii=1:N_sheets
    datatemp=xlsData{ii};
    for jj=1:N_cell
        rawdata(ii,:,jj)=datatemp(:,jj+1);
    end
end

% get deltaF/F for all running data
start_avgid=5;  %F0 Start frame number 7 second
end_avgid=7;  %F0 end frame number 9.7 second
baselineid=5;  %baselineid smallest order cell
for ii=1:N_sheets
    datatemp=xlsData{ii};
    baseline=sort(datatemp(:,1));
    sumcheck=sum(datatemp,2);
    Nozeros_index=find(sumcheck~=0);
    Zeros_index=find(sumcheck==0);
    N_zero=length(find(sumcheck==0));
    for jj=1:N_cell
        
        for kk=Nozeros_index
            deltaFoverFrun(ii,kk,jj)=(datatemp(kk,jj+1)-mean(datatemp(start_avgid:end_avgid,jj+1)))./squeeze((mean(datatemp(start_avgid:end_avgid,jj+1))-baseline(N_zero+round(0.01*baselineid*length(datatemp(:,1))))));
        end
        for kk=Zeros_index
            deltaFoverFrun(ii,kk,jj)=0;
        end
        
    end
end

% get deltaF/F for all rest data
F0id=10; %F0% smallest order cell
baselineid=5;  % baselineid smallest order cell
for ii=1:N_sheets
    datatemp=xlsData{ii};
    baseline=sort(datatemp(:,1));
    sumcheck=sum(datatemp,2);
    Nozeros_index=find(sumcheck~=0);
    Zeros_index=find(sumcheck==0);
    N_zero=length(find(sumcheck==0));
    for jj=1:N_cell
        
        
        for kk=Nozeros_index
            F0=sort(datatemp(:,jj+1));
            deltaFoverFrest(ii,kk,jj)=(datatemp(kk,jj+1)-F0(N_zero+round(0.01*F0id*length(datatemp(:,1)))))./squeeze((F0(N_zero+round(0.01*F0id*length(datatemp(:,1))))-baseline(N_zero+round(0.01*baselineid*length(datatemp(:,1))))));
        end
        for kk=Zeros_index
            deltaFoverFrest(ii,kk,jj)=0;
        end
    end
end

% get deltaF/F for all data

deltaFoverF=deltaFoverFrun;
deltaFoverF(restid,:,:)=deltaFoverFrest(restid,:,:);

delete([xlsfoldername '\Processing\deltaFoverF.xlsx']);

for ii=1:N_sheets
    xlswrite([xlsfoldername '\Processing\deltaFoverF.xlsx'],squeeze(deltaFoverF(ii,:,:)),Name_sheets{ii});
end
disp('Calculate deltaF/F done!!')

%% deltaFoverF plot
offsetdFF=-1;
for ii=1:N_sheets
    for jj=1:N_cell
        k33=figure(3784);
        figure(k33);
        plot(xvector,deltaFoverF(ii,:,jj)+jj*offsetdFF,'k','Linewidth',2);hold on;
        xlabel('Time/s');
        ylabel('\DeltaF/F');
        title(Name_sheets{ii});
        xlim([min(xvector) max(xvector)])
        set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
    end
    ylim([offsetdFF*N_cell-5 10])
    hold off;
    saveas(gcf,[xlsfoldername '\Processing\dFF\pdf\' Name_sheets{ii} '_dFF.pdf']);
    saveas(gcf,[xlsfoldername '\Processing\dFF\jpg\' Name_sheets{ii} '_dFF.jpg']);
    %     saveas(gcf,[xlsfoldername '\Processing\dFF\fig\' Name_sheets{ii} '_dFF.fig']);
    close(k33);
    
end



%% preview deltaF/F and save jpg
for id_sheets=1:N_sheets
    for id_cell=1:N_cell
        k=figure(3435);
        plot(xvector,squeeze(deltaFoverF(id_sheets,:,id_cell)));
        title([Name_sheets{id_sheets} ' cell' num2str(id_cell)]);
        xlabel('Time/s');
        ylabel('\DeltaF/F');
        xlim([min(xvector) max(xvector)])
        set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
        %         saveas(gcf,[xlsfoldername '\Processing\Trace plot\deltaFoverF_' Name_sheets{id_sheets} 'cell' num2str(id_cell) '.jpg']);
        pause(0.8)
        close(k);
    end
end
%% normlized data
for ii=1:N_sheets
    data_ori=squeeze(deltaFoverF(ii,:,:));
    aa=max(data_ori,[],1);
    
    method_id=1;
    
    if method_id==1
        % 1st method fix number
        threshold=0.5;
        ID1=find(aa>threshold);
        ID1_rest=find(aa<=threshold);
    elseif method_id==2
        % 2nd method 3 times of std
        threshold=2;
        bb=std(data_ori,0,1);
        ID1=find(aa>threshold*bb);
        ID1_rest=find(aa<=threshold*bb);
    end
    
    data_new=data_ori(:,ID1);
    [m,I]=max(data_new);
    [B,I1]=sort(I);
    I_final=([ID1(I1),ID1_rest]);
    data=data_ori(:,I_final);
    
    for i=1:N_cell
        data_norm(:,i)=(data(:,i)-min(data(:,i)))/(max(data(:,i))-min(data(:,i)));
    end
    k1=figure(222);
    figure(k1);
    imagesc(data_norm(:,:).');
    colormap jet;
    colorbar;
    % caxis([0 1.5]);
    xlabel('Time/s');
    ylabel('Cell number');
    title([Name_sheets{ii} ' Normalized Sequence']);
    
    %     saveas(gcf,[xlsfoldername '\Processing\Normilzed sequence\' Name_sheets{ii} '_data_norm.tif']);
    saveas(gcf,[xlsfoldername '\Processing\Normilzed sequence\' Name_sheets{ii} '_data_norm.pdf']);
    saveas(gcf,[xlsfoldername '\Processing\Normilzed sequence\' Name_sheets{ii} '_data_norm.jpg']);
    saveas(gcf,[xlsfoldername '\Processing\Normilzed sequence\' Name_sheets{ii} '_data_norm.fig']);
    close(k1);
    
    data_norm_All(:,:,ii)=data_norm(:,I_final).';
    
    %% real data1
    
    k2=figure(333);
    figure(k2);
    imagesc(data(:,:).');
    colormap jet;
    colorbar;
    caxis([0 5]);
    xlabel('Time/s');
    ylabel('Cell number');
    title([Name_sheets{ii} ' Real Sequence']);
    
    %     saveas(gcf,[xlsfoldername '\Processing\Real sequence\' Name_sheets{ii} '_real_data.tif']);
    saveas(gcf,[xlsfoldername '\Processing\Real sequence\' Name_sheets{ii} '_real_data.pdf']);
    saveas(gcf,[xlsfoldername '\Processing\Real sequence\' Name_sheets{ii} '_real_data.jpg']);
    saveas(gcf,[xlsfoldername '\Processing\Real sequence\' Name_sheets{ii} '_real_data.fig']);
    close(k2);
    
    data_All(:,:,ii)=data(:,I_final).';
    
    %% plot data
    
    offset=-1;
    k3=figure(3764);
    figure(k3);
    for jj=1:N_cell
        plot(xvector,data(:,jj)+jj*offset);hold on;
        deletaFoverF_All(jj,:,ii)=(data(:,jj));
    end
    hold off;
    xlabel('Time/s');
    ylabel('\DeltaF/F');
    title(Name_sheets{ii});
    xlim([min(xvector) max(xvector)])
    set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
    
    %     axis off;
    %     saveas(gcf,[xlsfoldername '\Processing\Plot sequence\' Name_sheets{ii} '_deltaFoverFall.tif']);
    saveas(gcf,[xlsfoldername '\Processing\Plot sequence\' Name_sheets{ii} '_deltaFoverFall.pdf']);
    saveas(gcf,[xlsfoldername '\Processing\Plot sequence\' Name_sheets{ii} '_deltaFoverFall.jpg']);
    saveas(gcf,[xlsfoldername '\Processing\Plot sequence\' Name_sheets{ii} '_deltaFoverFall.fig']);
    close(k3);
    
end

% saveas xls
for ii=1:N_sheets
    delete([xlsfoldername '\Processing\Sequence' Name_sheets{ii} '.xlsx']);
    sheetname=[Name_sheets{ii} '_norm'];
    if length(sheetname)>31
        sheetname=[sheetname(1:5),sheetname(end-25:end) ] ;
    end
    xlswrite([xlsfoldername '\Processing\Sequence' Name_sheets{ii} '.xlsx'],squeeze(data_norm_All(:,:,ii)),sheetname);
    sheetname=[Name_sheets{ii} '_real'];
    if length(sheetname)>31
        sheetname=[sheetname(1:5),sheetname(end-25:end) ] ;
    end
    xlswrite([xlsfoldername '\Processing\Sequence' Name_sheets{ii} '.xlsx'],squeeze(data_All(:,:,ii)),sheetname);
    sheetname=[Name_sheets{ii} '_deltaF'];
    if length(sheetname)>31
        sheetname=[sheetname(1:5),sheetname(end-25:end) ] ;
    end
    xlswrite([xlsfoldername '\Processing\Sequence' Name_sheets{ii} '.xlsx'],squeeze(deletaFoverF_All(:,:,ii)),sheetname);
    sheetname=[Name_sheets{ii} '_reorder'];
    if length(sheetname)>31
        sheetname=[sheetname(1:5),sheetname(end-25:end) ] ;
    end
    xlswrite([xlsfoldername '\Processing\Sequence' Name_sheets{ii} '.xlsx'],squeeze(I_final'),sheetname);
end
disp('Sequence is done!!')
%% Single cell plot
idtoplot=[1]; %% sheet id to plot e.g. run1
offsetgray=-1;
% gray plot
for jj=1:N_cell
    k6=figure(3836);
    figure(k6);
    id_offset1=0;
    
    for ii=1:length(idtoplot)
        plot(xvector,squeeze(deltaFoverF(idtoplot(ii),:,jj))+id_offset1*offsetgray,'k','Linewidth',2);
        singlecell_All(:,ii,jj)=squeeze(deltaFoverF(idtoplot(ii),:,jj));
        id_offset1=id_offset1+1;
        hold on;
    end
    hold off
    set(gca,'FontSize',15);
    title(['cell' num2str(jj)]);
    %     colormap(gray)
    xlabel('Time/s');
    ylabel('\DeltaF/F');
    xlim([min(xvector) max(xvector)]);
    ylim([-6 8]); %% change the y axis range
    set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
    
    %     saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell G' num2str(jj) '_gray.tif']);
    saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell G' num2str(jj) '_gray.jpg']);
    saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell G' num2str(jj) '_gray.pdf']);
    saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell G' num2str(jj) '_gray.fig']);
    close(k6);
end

% color plot

offsetcolor=0;
legendname={};
for jj=1:N_cell
    k7=figure(3837);
    figure(k7);
    id_offset1=0;
    for ii=1:length(idtoplot)
        plot(xvector,squeeze(deltaFoverF(idtoplot(ii),:,jj))+id_offset1*offsetcolor,'Linewidth',2);
        legendname{ii}=Name_sheets{idtoplot(ii)};
        id_offset1=id_offset1+1;
        hold on;
    end
    hold off
    legend(legendname)
    set(gca,'FontSize',15);
    title(['cell' num2str(jj)]);
    xlim([min(xvector) max(xvector)])
    ylim([-1 8.5]); %% change the y axis range
    set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
    %     colormap(gray)
    xlabel('Time/s');
    ylabel('\DeltaF/F');
    
    %     saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell C' num2str(jj) '_color.tif']);
    saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell C' num2str(jj) '_color.jpg']);
    saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell C' num2str(jj) '_color.pdf']);
    %     saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell C' num2str(jj) '_color' ], 'epsc');
    saveas(gcf,[xlsfoldername '\Processing\Single cell plot\singlecell C' num2str(jj) '_color.fig']);
    close(k7);
end

headers3=cell(size(singlecell_All,2),size(singlecell_All,3));
for ii=1:N_cell
    for jj=1:length(idtoplot)
        headers3{jj,ii}=['cell' num2str(ii) Name_sheets{idtoplot(jj)}];
    end
end
headers3=reshape(headers3,1,size(singlecell_All,2)*size(singlecell_All,3));
singlecell_reshape_All=reshape(singlecell_All,size(singlecell_All,1),size(singlecell_All,2)*size(singlecell_All,3));

delete([xlsfoldername '\Processing\singlecell' num2str(idtoplot) '.xlsx']);
xlswrite([xlsfoldername '\Processing\singlecell' num2str(idtoplot) '.xlsx'],[headers3;num2cell(singlecell_reshape_All)]);

save([xlsfoldername '\Processing\workspace.mat'])

disp('Single cell done!!')

%% analysis every trace
clear PARAS
threshold_analysis=0.5;
T_run=60; % run duration in second
T_run_start=12; % start running time point in the data, in second
minleft1=round(T_run_start*framerate);
minrightend=round((T_run_start+T_run)*framerate);

clear num_analysis Peakamp_Avg Duration_Avg Freq Aera_per_peak Aera_per_second
Peakamp_Avg=zeros(N_cell,N_sheets);
N_Peak=zeros(N_cell,N_sheets);
Duration_Avg=zeros(N_cell,N_sheets);
Freq=zeros(N_cell,N_sheets);
Aera_per_peak=zeros(N_cell,N_sheets);
Aera_per_second=zeros(N_cell,N_sheets);
analysisid=0;

for kk=1:N_sheets
    kk
    
    for jj=1:N_cell
        k336=figure(37842);
        figure(k336);
        plot(xvector,deltaFoverF(kk,:,jj)+jj*offsetdFF,'k','Linewidth',2);hold on;
        xlabel('Time/s');
        ylabel('\DeltaF/F');
        title(Name_sheets{kk});
        xlim([min(xvector) max(xvector)])
        set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
    end
    ylim([offsetdFF*N_cell-5 10])
    hold off;
    %     saveas(gcf,[xlsfoldername '\Processing\dFF\' Name_sheets{ii} '_dFF.pdf']);
    %     saveas(gcf,[xlsfoldername '\Processing\dFF\' Name_sheets{ii} '_dFF.jpg']);
    %     saveas(gcf,[xlsfoldername '\Processing\dFF\' Name_sheets{ii} '_dFF.fig']);
    %     close(k336);
    
    %% check if further analysis is needed
    inputOptions={'Yes', 'No and go to next data'};
    defSelection=inputOptions{1};
    iSel=bttnChoiseDialog(inputOptions, 'CheckDialog', defSelection,...
        'Analysis this data?');
    if iSel==1
        close(k336);
        if kk==1
            num_analysis=1;
        elseif kk>1 && exist('num_analysis')
            num_analysis=num_analysis+1;
        elseif kk>1 && ~exist('num_analysis')
            num_analysis=1;
        end
        analysisid=1;
        Name_sheets_analysis{num_analysis}=Name_sheets{kk};
        Index_sheets_analysis(num_analysis)=kk;
    end
    
    N_cell_act=0;
    Aera_act=0;
    Duration_act=0;
    Peakamp_act=0;
    Fequency_act=0;
    while(analysisid)
        for ii=1:N_cell
            ii
            fig = figure(223534);
            temp=squeeze(deltaFoverF(kk,:,ii));
            plot(temp,'k');
            ylim([min(temp)-3 max(temp)+3]);
            hold on; plot(threshold_analysis*ones(size(temp)),'r.');
            hold on; plot([T_run_start*framerate,T_run_start*framerate],[min(temp) max(temp)],'r.');
            hold on; plot([(T_run_start+T_run)*framerate,(T_run_start+T_run)*framerate],[min(temp) max(temp)],'r.');
            title(['Cell' num2str(ii) Name_sheets{kk}]);
            hold off;
            dcm_obj = datacursormode(fig);
            set(dcm_obj,'DisplayStyle','datatip',...
                'SnapToDataVertex','off','Enable','on')
            waitfor(msgbox('Click OK to continue'));
            disp('Done waiting.');
            saveas(gcf,[xlsfoldername '\Processing\Trace analysis\Cell' num2str(ii) Name_sheets{kk} '.pdf']);
            saveas(gcf,[xlsfoldername '\Processing\Trace analysis\Cell' num2str(ii) Name_sheets{kk} '.jpg']);
            c_info = getCursorInfo(dcm_obj);
            max_ind_select=[];
            if isempty(c_info)~=1
                %% remoe peak out of running period
                cc=squeeze(struct2cell(c_info));
                %             max_ind_select=cell2mat(cc(3,:));
                max_ind_select=cell2mat(cc(2,:));
                max_ind_select=max_ind_select(1:2:end);
                [pks,locs]=findpeaks(temp);
                max_ind_select=max_ind_select(max_ind_select>T_run_start*framerate);
                max_ind_select=max_ind_select(max_ind_select<(T_run_start+T_run)*framerate);
            end
            if isempty(max_ind_select)~=1
                N_cell_act=N_cell_act+1;
                %                 cc=squeeze(struct2cell(c_info));
                %                 %             max_ind_select=cell2mat(cc(3,:));
                %                 max_ind_select=cell2mat(cc(2,:));
                %                 max_ind_select=max_ind_select(1:2:end);
                [pks,locs]=findpeaks(temp);
                %% get the accurate max index
                for jj=1:length(max_ind_select)
                    [c index] = min(abs(locs-max_ind_select(jj)));
                    max_ind_final_select(jj)=locs(index);
                end
                max_ind_final_select=sort(max_ind_final_select);
                
                checkid=0;
                max_ind_final=[];
                for jj=1:length(max_ind_final_select)
                    if temp(max_ind_final_select(jj))>threshold_analysis
                        max_ind_final(checkid+1)=max_ind_final_select(jj);
                        checkid=checkid+1;
                    end
                end
                if isempty(max_ind_final)~=1
                    %% get paras
                    % find threshold index at both sides of peaks
                    for jj=1:length(max_ind_final)
                        
                        if size(temp,2)==1
                            left_vec=flipud(temp(1:max_ind_final(jj)));
                        elseif size(temp,1)==1
                            left_vec=fliplr(temp(1:max_ind_final(jj)));
                        end
                        id1=find(left_vec<max(threshold_analysis,0.5*temp(max_ind_final(jj))),1); %FWHM
                        %                     id1=find(left_vec<threshold_analysis,1);
                        
                        if jj==1
                            if isempty(id1)==1
                                min_left(jj)=1;
                            else
                                min_left(jj)=max_ind_final(jj)-id1+2;
                            end
                        elseif jj>1
                            if isempty(id1)==1
                                min_left(jj)=1;
                                if min_left(jj)<=max_ind_final(jj-1)
                                    [c index]=min(temp(max_ind_final(jj-1):max_ind_final(jj)));
                                    min_left(jj)=max_ind_final(jj-1)+index-1;
                                end
                            else
                                min_left(jj)=max_ind_final(jj)-id1+2;
                                if min_left(jj)<=max_ind_final(jj-1)
                                    [c index]=min(temp(max_ind_final(jj-1):max_ind_final(jj)));
                                    min_left(jj)=max_ind_final(jj-1)+index-1;
                                end
                            end
                            
                        end
                        
                        right_vec=temp(max_ind_final(jj):end);
                        %                     id2=find(right_vec<threshold_analysis,1);
                        id2=find(right_vec<max(0.5*temp(max_ind_final(jj)),threshold_analysis),1);
                        if isempty(id2)
                            id2=length(temp(max_ind_final(jj):end));
                        end
                        if jj <length(max_ind_final)
                            min_right(jj)=max_ind_final(jj)+id2-2;
                            if min_right(jj)>=max_ind_final(jj+1)
                                [c index]=min(temp(max_ind_final(jj):max_ind_final(jj+1)));
                                min_right(jj)=max_ind_final(jj)+index-1;
                            end
                            
                        elseif jj==length(max_ind_final)
                            if isempty(id2)==1
                                min_right(jj)=length(temp);
                            else
                                min_right(jj)=max_ind_final(jj)+id2-2;
                            end
                        end
                        
                        if min_right(jj)>minrightend
                            min_right(jj)=minrightend;
                        end
                        
                        if min_left(jj)<minleft1
                            min_left(jj)=minleft1;
                        end
                        
                        %                     id1
                        %                     id2
                        min_right(jj)
                        min_left(jj)
                        
                        Peakamp(jj)=temp(max_ind_final(jj));
                        Duration(jj)=(min_right(jj)-min_left(jj)+1)/framerate;
                        Aera(jj)=sum(temp(min_left(jj):min_right(jj)));%-threshold_analysis*(min_right(jj)-min_left(jj)+1);
                        Aera_act=Aera_act+Aera(jj);
                        Duration_act=Duration_act+Duration(jj);
                        Peakamp_act=Peakamp_act+Peakamp(jj);
                        
                        PARAS(ii,jj,kk,1)=max_ind_final(jj);
                        PARAS(ii,jj,kk,2)=(max_ind_final(jj)-1)/framerate;
                        PARAS(ii,jj,kk,3)=Peakamp(jj);
                        PARAS(ii,jj,kk,4)=Duration(jj);
                        PARAS(ii,jj,kk,5)=Aera(jj);
                        
                        clear left_vec right_vec min_right min_left
                    end
                    Peakamp_Avg(ii,kk)=mean(Peakamp);
                    N_Peak(ii,kk)=length(max_ind_select);
                    Duration_Avg(ii,kk)=mean(Duration);
                    Freq(ii,kk)=((length(find(max_ind_final>=(T_run_start*framerate)))) + length(find(max_ind_final<=((T_run_start+T_run)*framerate)))-length(max_ind_final))/T_run;
                    Aera_per_peak(ii,kk)=sum(Aera(:))/length(max_ind_final);
                    Aera_per_second(ii,kk)=sum(Aera(:))/T_run;
                    
                    clear max_ind_final max_ind_final_select max_ind_select temp dcm_obj cc c_info bb pks locs Peakamp Duration Aera
                else
                    
                    PARAS(ii,jj,kk,1)=0;
                    PARAS(ii,jj,kk,2)=0;
                    PARAS(ii,jj,kk,3)=0;
                    PARAS(ii,jj,kk,4)=0;
                    PARAS(ii,jj,kk,5)=0;
                    
                    Peakamp_Avg(ii,kk)=0;
                    Duration_Avg(ii,kk)=0;
                    Freq(ii,kk)=0;
                    Aera_per_peak(ii,kk)=0;
                    Aera_per_second(ii,kk)=0;
                end
            else
                
                PARAS(ii,jj,kk,1)=0;
                PARAS(ii,jj,kk,2)=0;
                PARAS(ii,jj,kk,3)=0;
                PARAS(ii,jj,kk,4)=0;
                PARAS(ii,jj,kk,5)=0;
                
                Peakamp_Avg(ii,kk)=0;
                Duration_Avg(ii,kk)=0;
                Freq(ii,kk)=0;
                Aera_per_peak(ii,kk)=0;
                Aera_per_second(ii,kk)=0;
            end
        end
        analysisid=0;
    end
    N_cell_act_all(kk)=N_cell_act;
    Aera_pre_sheet_act(kk)=Aera_act;
    Duration_pre_sheet_act(kk)=Duration_act;
    Peakamp_pre_sheet_act(kk)=Peakamp_act;
    if N_cell_act_all(kk)==0
        Freq_pre_sheet_act(kk)=0;
    else
        Freq_pre_sheet_act(kk)=sum(Freq(:,kk))/N_cell_act_all(kk);
    end
    if iSel==2
        analysisid=0;
        PARAS(1,1,kk,1)=0;
        PARAS(1,1,kk,2)=0;
        PARAS(1,1,kk,3)=0;
        PARAS(1,1,kk,4)=0;
        PARAS(1,1,kk,5)=0;
        Peakamp_Avg(:,kk)=0;
        Duration_Avg(:,kk)=0;
        Freq(:,kk)=0;
        Aera_per_peak(:,kk)=0;
        Aera_per_second(:,kk)=0;
    end
end

if exist('fig')
close(fig)
end

clear Summary Details Cell_act_analysis
clear Cellname Sheetname
for ii=1:N_cell
    %     for jj=1:size(PARAS,3)
    for jj=1:N_sheets
        Cellname{ii,jj}=['Cell' num2str(ii)];
        Sheetname{ii,jj}=Name_sheets{jj};
        
    end
end

Summary(:,:,1)=Cellname;
Summary(:,:,2)=Sheetname;
Summary(:,:,3)=num2cell(Peakamp_Avg);
Summary(:,:,4)=num2cell(N_Peak);
Summary(:,:,5)=num2cell(Duration_Avg);
Summary(:,:,6)=num2cell(Freq);
Summary(:,:,7)=num2cell(Aera_per_peak);
Summary(:,:,8)=num2cell(Aera_per_second);

Summary=reshape(Summary,size(Peakamp_Avg,1)*size(Peakamp_Avg,2),8);

clear Cellname Sheetname

for ii=1:N_cell
    for jj=1:N_sheets
        %     for jj=1:size(PARAS,3)
        for kk=1:size(PARAS,2)
            Cellname{ii,kk,jj}=['Cell' num2str(ii)];
            Sheetname{ii,kk,jj}=Name_sheets{jj};
        end
    end
end

Details(:,:,:,1)=Cellname;
Details(:,:,:,2)=Sheetname;
Details(:,:,:,3:7)=num2cell(PARAS);

Details=reshape(Details,size(Details,1)*size(Details,2)*size(Details,3),7);
Cell_act_analysis(:,1)=Name_sheets;
Cell_act_analysis(:,2)=num2cell(N_cell_act_all');
Cell_act_analysis(:,3)=num2cell(Aera_pre_sheet_act');
Cell_act_analysis(:,4)=num2cell(Duration_pre_sheet_act');
Cell_act_analysis(:,5)=num2cell(Peakamp_pre_sheet_act');
Cell_act_analysis(:,6)=num2cell(Freq_pre_sheet_act');
Cell_act_analysis(:,7)=num2cell(Aera_pre_sheet_act'./N_cell_act_all');
Cell_act_analysis(:,8)=num2cell(Duration_pre_sheet_act'./N_cell_act_all');
Cell_act_analysis(:,9)=num2cell(Peakamp_pre_sheet_act'./N_cell_act_all');
Cell_act_analysis(:,10)=num2cell(Freq_pre_sheet_act'./N_cell_act_all');

delete([xlsfoldername '\Processing\Trace_analysis_PARAS.xls']);
headers1 = {'Cell','Sheet','Peak_index','Peak_time(s)','Peak_amplitude','Duration(s)','Aera'};
headers2 = {'Cell','Sheet','Peak_Avg','N_Peak','Duration_Avg()','Frequency(Hz)','Aera per peak','Aera per second'};
headers3 = {'Sheet','N_cell_act','Aera_pre_trail','Duration_pre_trail','Peak_pre_trail','Frequency_pre_trail','Aera_pre_trail_pre_cell','Duration_pre_trail_pre_cell','Peak_pre_trail_pre_cell','Frequency_pre_trail_pre_cell'};
for mm=1:3
    if mm==1
        info_to_write2 = [headers2; Summary];
        xlswrite([xlsfoldername '\Processing\Trace_analysis_PARAS.xlsx'],info_to_write2,'summary');
    elseif mm==2
        info_to_write1 = [headers1; Details];
        xlswrite([xlsfoldername '\Processing\Trace_analysis_PARAS.xlsx'],info_to_write1,'details');
    elseif mm==3
        info_to_write3 = [headers3; Cell_act_analysis];
        xlswrite([xlsfoldername '\Processing\Trace_analysis_PARAS.xlsx'],info_to_write3,'Cell_trail_comparsion');
    end
    
    
end

save([xlsfoldername '\Processing\workspace.mat'])

clear Summary Deatils

disp('Trace analysis done!!!')

%% run for a specific trace

threshold_analysis=0.3;
T_run=60; % in second
T_run_start=60; % in second
for ii=1 %N_cell
    ii
    for kk=2 %N_sheets
        kk
        fig = figure(223534);
        temp=squeeze(deltaFoverF(kk,:,ii));
        plot(temp,'k');
        ylim([min(temp)-3 max(temp)+3]);
        hold on; plot(threshold_analysis*ones(size(temp)),'r.');
        hold on; plot([T_run_start,T_run_start],[min(temp) max(temp)],'r.');
        hold on; plot([T_end,T_end],[min(temp) max(temp)],'r.');
        title(['Cell' num2str(ii) Name_sheets{kk}]);
        hold off;
        dcm_obj = datacursormode(fig);
        set(dcm_obj,'DisplayStyle','datatip',...
            'SnapToDataVertex','off','Enable','on')
        waitfor(msgbox('Click OK to continue'));
        disp('Done waiting.');
        saveas(gcf,[xlsfoldername '\Processing\Trace analysis\Cell' num2str(ii) Name_sheets{kk} '.pdf']);
        saveas(gcf,[xlsfoldername '\Processing\Trace analysis\Cell' num2str(ii) Name_sheets{kk} '.fig']);
        c_info = getCursorInfo(dcm_obj);
        if isempty(c_info)~=1
            cc=squeeze(struct2cell(c_info));
            %             max_ind_select=cell2mat(cc(3,:));
            max_ind_select=cell2mat(cc(2,:));
            max_ind_select=max_ind_select(1:2:end);
            [pks,locs]=findpeaks(temp);
            %% get the accurate max index
            for jj=1:length(max_ind_select)
                [c index] = min(abs(locs-max_ind_select(jj)));
                max_ind_final_select(jj)=locs(index);
            end
            max_ind_final_select=sort(max_ind_final_select);
            
            checkid=0;
            max_ind_final=[];
            for jj=1:length(max_ind_final_select)
                if temp(max_ind_final_select(jj))>threshold_analysis
                    max_ind_final(checkid+1)=max_ind_final_select(jj);
                    checkid=checkid+1;
                end
            end
            if isempty(max_ind_final)~=1
                %% get paras
                % find threshold index at both sides of peaks
                for jj=1:length(max_ind_final)
                    
                    if size(temp,2)==1
                        left_vec=flipud(temp(1:max_ind_final(jj)));
                    elseif size(temp,1)==1
                        left_vec=fliplr(temp(1:max_ind_final(jj)));
                    end
                    id1=find(left_vec<threshold_analysis,1);
                    
                    if jj==1
                        if isempty(id1)==1
                            min_left(jj)=1;
                        else
                            min_left(jj)=max_ind_final(jj)-id1+2;
                        end
                    elseif jj>1
                        min_left(jj)=max_ind_final(jj)-id1+2;
                        if min_left(jj)<=max_ind_final(jj-1)
                            [c index]=min(temp(max_ind_final(jj-1):max_ind_final(jj)));
                            min_left(jj)=max_ind_final(jj-1)+index-1;
                        end
                    end
                    
                    right_vec=temp(max_ind_final(jj):end);
                    id2=find(right_vec<threshold_analysis,1);
                    if jj <length(max_ind_final)
                        min_right(jj)=max_ind_final(jj)+id2-2;
                        if min_right(jj)>=max_ind_final(jj+1)
                            [c index]=min(temp(max_ind_final(jj):max_ind_final(jj+1)));
                            min_right(jj)=max_ind_final(jj)+index-1;
                        end
                        
                    elseif jj==length(max_ind_final)
                        if isempty(id2)==1
                            min_right(jj)=length(temp);
                        else
                            min_right(jj)=max_ind_final(jj)+id2-2;
                        end
                    end
                    
                    Peakamp(jj)=temp(max_ind_final(jj));
                    Duration(jj)=(min_right(jj)-min_left(jj)+1)/framerate;
                    Aera(jj)=sum(temp(min_left(jj):min_right(jj)))-threshold_analysis*(min_right(jj)-min_left(jj)+1);
                    
                    
                    PARAS(ii,jj,kk,1)=max_ind_final(jj);
                    PARAS(ii,jj,kk,2)=(max_ind_final(jj)-1)/framerate;
                    PARAS(ii,jj,kk,3)=Peakamp(jj);
                    PARAS(ii,jj,kk,4)=Duration(jj);
                    PARAS(ii,jj,kk,5)=Aera(jj);
                    
                    clear left_vec id1 right_vec id2 min_right min_left
                end
                if length(max_ind_final)<size(PARAS,2)
                    for ll=jj+1:size(PARAS,2)
                        PARAS(ii,ll,kk,1)=0;
                        PARAS(ii,ll,kk,2)=0;
                        PARAS(ii,ll,kk,3)=0;
                        PARAS(ii,ll,kk,4)=0;
                        PARAS(ii,ll,kk,5)=0;
                    end
                end
                
                Peakamp_Avg(ii,kk)=mean(Peakamp);
                Duration_Avg(ii,kk)=mean(Duration);
                Freq(ii,kk)=((length(find(max_ind_final>=(T_run_start*framerate)))) + length(find(max_ind_final<=((T_run_start+T_run)*framerate)))-length(max_ind_final))/T_run;
                Aera_per_peak(ii,kk)=sum(Aera(:))/length(max_ind_final);
                Aera_per_second(ii,kk)=sum(Aera(:))/T_run;
                clear max_ind_final max_ind_final_select max_ind_select temp dcm_obj cc xvector c_info bb pks locs Peakamp Duration Aera
            else
                
                PARAS(ii,jj,kk,1)=0;
                PARAS(ii,jj,kk,2)=0;
                PARAS(ii,jj,kk,3)=0;
                PARAS(ii,jj,kk,4)=0;
                PARAS(ii,jj,kk,5)=0;
                
                Peakamp_Avg(ii,kk)=0;
                Duration_Avg(ii,kk)=0;
                Freq(ii,kk)=0;
                Aera_per_peak(ii,kk)=0;
                Aera_per_second(ii,kk)=0;
            end
        else
            
            PARAS(ii,jj,kk,1)=0;
            PARAS(ii,jj,kk,2)=0;
            PARAS(ii,jj,kk,3)=0;
            PARAS(ii,jj,kk,4)=0;
            PARAS(ii,jj,kk,5)=0;
            
            Peakamp_Avg(ii,kk)=0;
            Duration_Avg(ii,kk)=0;
            Freq(ii,kk)=0;
            Aera_per_peak(ii,kk)=0;
            Aera_per_second(ii,kk)=0;
        end
    end
end
close(fig)

clear Summary Details
clear Cellname Sheetname
for ii=1:N_cell
    for jj=1:N_sheets
        Cellname{ii,jj}=['Cell' num2str(ii)];
        Sheetname{ii,jj}=Name_sheets{jj};
        
    end
end


Summary(:,:,1)=Cellname;
Summary(:,:,2)=Sheetname;
Summary(:,:,3)=num2cell(Peakamp_Avg);
Summary(:,:,4)=num2cell(Duration_Avg);
Summary(:,:,5)=num2cell(Freq);
Summary(:,:,6)=num2cell(Aera_per_peak);
Summary(:,:,7)=num2cell(Aera_per_second);

Summary=reshape(Summary,size(Peakamp_Avg,1)*size(Peakamp_Avg,2),7);

clear Cellname Sheetname
for ii=1:N_cell
    for jj=1:N_sheets
        for kk=1:size(PARAS,2)
            Cellname{ii,kk,jj}=['Cell' num2str(ii)];
            Sheetname{ii,kk,jj}=Name_sheets{jj};
        end
    end
end

Details(:,:,:,1)=Cellname;
Details(:,:,:,2)=Sheetname;
Details(:,:,:,3:7)=num2cell(PARAS);

Details=reshape(Details,size(Details,1)*size(Details,2)*size(Details,3),7);

delete([xlsfoldername '\Processing\Trace_analysis_PARAS.xls']);
headers1 = {'Cell','Sheet','Peak_index', 'Peak_time(s)', 'Peak_amplitude', 'Duration(s)', 'Aera'};
headers2 = {'Cell','Sheet','Peak_Avg', 'Duration_Avg()', 'Frequency(Hz)', 'Aera per peak', 'Aera per second'};
for mm=1:2
    if mm==1
        info_to_write2 = [headers2; Summary];
        xlswrite([xlsfoldername '\Processing\Trace_analysis_PARAS.xls'],info_to_write2,'summary');
    else
        info_to_write1 = [headers1; Details];
        xlswrite([xlsfoldername '\Processing\Trace_analysis_PARAS.xls'],info_to_write1,'details');
    end
    
    
end

save([xlsfoldername '\Processing\workspace.mat'])

clear Summary Deatils