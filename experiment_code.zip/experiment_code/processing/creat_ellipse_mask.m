function [ellipsePixels]=creat_ellipse_mask(imageSizeX,imageSizeY,roivector)

[columnsInImage rowsInImage] = meshgrid(1:imageSizeX, 1:imageSizeY);

centerY = ((roivector(1)+roivector(3))/2);
centerX = ((roivector(2)+roivector(4))/2);
radiusY = (abs((roivector(1)-roivector(3)))/2);
radiusX = (abs((roivector(2)-roivector(4)))/2);
ellipsePixels = (rowsInImage - centerY).^2 ./ radiusY^2 ...
    + (columnsInImage - centerX).^2 ./ radiusX^2 <= 1;

end