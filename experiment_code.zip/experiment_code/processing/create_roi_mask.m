function [mask] = create_roi_mask(sizeX,sizeY,sROI)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if strcmp(sROI.strType,'Polygon')
mask = poly2mask(sROI.mnCoordinates(:,1),sROI.mnCoordinates(:,2),sizeX,sizeY);
elseif strcmp(sROI.strType,'Oval')
mask=creat_ellipse_mask(sizeX,sizeY,sROI.vnRectBounds);
end
end

