%% load roi zip file and get the raw data from imagej roi, created by Yiyong Han, 20181219
%load two channels stack data and get the green channel stack
clear all
close all
clc
dataDir = uigetdir;
subdir_info = dir(dataDir);
subdir_info(~[subdir_info.isdir]) = [];         %get rid of non folders
subdir_info(ismember({subdir_info.name}, {'.', '..'})) = [];  %get rid of . and ..
subdir_names = fullfile(dataDir, {subdir_info.name});    %construct list of names
for iii=1:length(subdir_names)
    selpath = subdir_names{iii};
    tiffileList = dir([ selpath '\*.tif']);
    tiffileList_cell=struct2cell(tiffileList);
    Threshold_bytesize=100; % unit in MB, select file size larger than this number
    tiffileList_select=tiffileList_cell(:,(cell2mat(tiffileList_cell(4,:)))>Threshold_bytesize*1024^2);
    N_needprocess=size(tiffileList_select,2);
    %load roi file in the same folder
    roifileList = dir([ selpath '\*.zip']);
    roifileList_cell=struct2cell(roifileList);
    [sROI] = ReadImageJROI([selpath '\' roifileList(1).name]);
    % read tif and get the image size
    FileTif=[selpath '\'  tiffileList_select{1,1}];
    InfoImage=imfinfo(FileTif);
    mImage=InfoImage(1).Width;
    nImage=InfoImage(1).Height;
    sizeX=mImage;
    sizeY=nImage;
    % creat mask stack
    ROI_mask=[];
    N_ROI=[];
    for ii=1:length(sROI)
        ROI_mask(:,:,ii)=create_roi_mask(sizeX,sizeY,sROI{ii});
        N_ROI(ii)=sum(sum(ROI_mask(:,:,ii)));
    end
    % read tiff stack and get the raw data
    delete([selpath '\rawdata.xls']);
    rawdata=[];
    for ii=1:1
        green=[];
        FileTif=[selpath '\'  tiffileList_select{1,ii}];
        InfoImage=imfinfo(FileTif);
        mImage=InfoImage(1).Width;
        nImage=InfoImage(1).Height;
        NumberImages=length(InfoImage);
        TifLink = Tiff(FileTif, 'r');
        for q=1:NumberImages  
            TifLink.setDirectory(q);
            green(:,:,q)=double(TifLink.read());
        end
        TifLink.close();
        warning off;
        for jj=1:length(sROI)
            for kk=1:size(green,3)
                rawdata(kk,jj,ii)=sum(sum(squeeze(green(:,:,kk)).*squeeze(ROI_mask(:,:,jj))))/N_ROI(jj);
            end
        end
    end
end
disp('ALL done!!!')
%% get deltaF/F for all rest data
framerate=1.68;
N_frames=size(rawdata,1);
Time_interval=50; % for figure plot, unit in second
xvector=(0:N_frames-1)/framerate;
F0id=10; %F0% smallest order cell
baselineid=5;  % baselineid smallest order cell
N_cell=size(rawdata,2)-1;
baseline=sort(rawdata(:,1));
% sumcheck=sum(rawdata,2);
for jj=1:N_cell
    F0=sort(rawdata(:,jj+1));
    deltaFoverF(:,jj)=(rawdata(:,jj+1)-F0(round(0.01*F0id*length(rawdata(:,1)))))./squeeze((F0(round(0.01*F0id*length(rawdata(:,1))))-baseline(round(0.01*baselineid*length(rawdata(:,1))))));
end
for id_cell=1:N_cell
    k=figure(3435);
    plot(xvector,squeeze(deltaFoverF(:,id_cell)));
    title([' cell' num2str(id_cell)]);
    xlabel('Time/s');
    ylabel('\DeltaF/F');
    xlim([min(xvector) max(xvector)])
    set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
    %         saveas(gcf,[xlsfoldername '\Processing\Trace plot\deltaFoverF_' Name_sheets{id_sheets} 'cell' num2str(id_cell) '.jpg']);
    pause(1)
    close(k);
end
%% plot data
offset=-2;
k3=figure(3764);
figure(k3);
for jj=1:N_cell
    plot(xvector,deltaFoverF(:,jj)+jj*offset,'k');hold on;
    %     deletaFoverF_All(jj,:,ii)=(data(:,jj));
end
hold off;
xlabel('Time/s');
ylabel('\DeltaF/F');
xlim([min(xvector) max(xvector)])
set(gca,'XTick',(min(xvector):Time_interval:round(max(xvector)/Time_interval)*Time_interval))
axis off