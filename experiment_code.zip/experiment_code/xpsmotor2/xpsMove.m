function [a,b,c]=xpsMove(x,y,z,socketID,positioner1,positioner2, positioner3);

[errorCode] = GroupMoveAbsolute(socketID, positioner3, z) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
return ;
end



[errorCode] = GroupMoveAbsolute(socketID, positioner1, x) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
return ;
end


[errorCode] = GroupMoveAbsolute(socketID, positioner2, y) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
return ;
end



[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner1, 1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']) ;
return ;
else
disp (['Positioner ' positioner1 ' is in position ' num2str(currentPosition)]) ;
a=currentPosition;
end

[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner2, 1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']) ;
return ;
else
disp (['Positioner ' positioner2 ' is in position ' num2str(currentPosition)]) ;
b=currentPosition;
end

[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner3, 1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']) ;
return ;
else
disp (['Positioner ' positioner3 ' is in position ' num2str(currentPosition)]) ;
c=currentPosition;
end