function varargout = StageControl(varargin)
% GUI MATLAB code for StageControl.fig
%      This function is used to give a GUI for Newport XPS stage control.
%
% Last Modified by GUIDE v2.5 27-Dec-2013 10:02:01
% coded by Hao,Xiang
% v0.1
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)

% Choose default command line output for GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%% connect to the transition stage
xps_load_drivers ;  % Load the library

global IP Port TimeOut socketID;  % parameters for connection
IP = '10.102.32.182' ;
Port = 5001 ;
TimeOut = 60.0 ;
% Connect to XPS
socketID = TCP_ConnectToServer (IP, Port, TimeOut) ;

if socketID<0 % check connection
    error('Connection to XPS failed, check IP & Port');
else
    disp('Connection successful!');
end

%% control
global group1 positioner1 group2 positioner2 group3 positioner3; % parameters for controlling
group1 = 'GROUP1' ;
positioner1 = 'GROUP1.POSITIONER' ;
group2 = 'GROUP2' ;
positioner2 = 'GROUP2.POSITIONER' ;
group3 = 'GROUP3' ;
positioner3 = 'GROUP3.POSITIONER' ;

% get current position
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner1, 1) ; % x
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    set(handles.xPosition,'String',num2str(currentPosition));
end
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner2, 1) ; % y
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    set(handles.yPosition,'String',num2str(currentPosition));
end
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner3, 1) ; % z
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    set(handles.zPosition,'String',num2str(currentPosition));
end

% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function xyStepLength_Callback(hObject, eventdata, handles)
% hObject    handle to xyStepLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xyStepLength as text
%        str2double(get(hObject,'String')) returns contents of xyStepLength as a double


% --- Executes during object creation, after setting all properties.
function xyStepLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xyStepLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function zStepLength_Callback(hObject, eventdata, handles)
% hObject    handle to zStepLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of zStepLength as text
%        str2double(get(hObject,'String')) returns contents of zStepLength as a double


% --- Executes during object creation, after setting all properties.
function zStepLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zStepLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function relativeAngle_Callback(hObject, eventdata, handles)
% hObject    handle to relativeAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of relativeAngle as text
%        str2double(get(hObject,'String')) returns contents of relativeAngle as a double


% --- Executes during object creation, after setting all properties.
function relativeAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to relativeAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in positiveYMove.
function positiveYMove_Callback(hObject, eventdata, handles)
% hObject    handle to positiveYMove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get step length
xyStep=str2double(get(handles.xyStepLength,'String'));
angle=str2double(get(handles.relativeAngle,'String'))*pi/180;
yStep=xyStep*cos(angle);
xStep=xyStep*sin(angle);

% relatively move
global socketID positioner1 positioner2;  % call y
[errorCode] = GroupMoveRelative(socketID, positioner2, yStep) ;
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end
[errorCode] = GroupMoveRelative(socketID, positioner1, xStep) ;  % call x
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end

% --- Executes on button press in negativeXMove.
function negativeXMove_Callback(hObject, eventdata, handles)
% hObject    handle to negativeXMove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
xyStep=0-str2double(get(handles.xyStepLength,'String'));
angle=str2double(get(handles.relativeAngle,'String'))*pi/180;
xStep=xyStep*cos(angle);
yStep=xyStep*sin(angle);

% relatively move
global socketID positioner1 positioner2;  
[errorCode] = GroupMoveRelative(socketID, positioner1, xStep) ;  % call x
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end
[errorCode] = GroupMoveRelative(socketID, positioner2, yStep) ;  % call y
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end

% --- Executes on button press in positiveXMove.
function positiveXMove_Callback(hObject, eventdata, handles)
% hObject    handle to positiveXMove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
xyStep=str2double(get(handles.xyStepLength,'String'));
angle=str2double(get(handles.relativeAngle,'String'))*pi/180;
xStep=xyStep*cos(angle);
yStep=xyStep*sin(angle);

% relatively move
global socketID positioner1 positioner2;  
[errorCode] = GroupMoveRelative(socketID, positioner1, xStep) ; % call x
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end
[errorCode] = GroupMoveRelative(socketID, positioner2, yStep) ; % call y
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end

% --- Executes on button press in negativeYMove.
function negativeYMove_Callback(hObject, eventdata, handles)
% hObject    handle to negativeYMove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
xyStep=0-str2double(get(handles.xyStepLength,'String'));
angle=str2double(get(handles.relativeAngle,'String'))*pi/180;
yStep=xyStep*cos(angle);
xStep=xyStep*sin(angle);

% relatively move
global socketID positioner1 positioner2;  
[errorCode] = GroupMoveRelative(socketID, positioner2, yStep) ;  % call y
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end
[errorCode] = GroupMoveRelative(socketID, positioner1, xStep) ; % call x
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end

% --- Executes on button press in positiveZMove.
function positiveZMove_Callback(hObject, eventdata, handles)
% hObject    handle to positiveZMove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
zStep=str2double(get(handles.zStepLength,'String'));

% relatively move
global socketID positioner3;  % call z
[errorCode] = GroupMoveRelative(socketID, positioner3, zStep) ;
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end

% --- Executes on button press in negativeZMove.
function negativeZMove_Callback(hObject, eventdata, handles)
% hObject    handle to negativeZMove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
zStep=str2double(get(handles.zStepLength,'String'));
zMin=str2double(get(handles.zLimit,'String'));

% relatively move
global socketID positioner3;  % call z
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner3, 1) ;  % get current position
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    if currentPosition-zStep<zMin  % to check if the position exceeds z limit
        msgbox('position exceeds z Limit, try a smaller step!');
        error('position exceeds z Limit, try a smaller step!');
    end
end
[errorCode] = GroupMoveRelative(socketID, positioner3, -zStep) ;
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupMoveRelative ! ']);
end

function setX_Callback(hObject, eventdata, handles)
% hObject    handle to setX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setX as text
%        str2double(get(hObject,'String')) returns contents of setX as a double


% --- Executes during object creation, after setting all properties.
function setX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setY_Callback(hObject, eventdata, handles)
% hObject    handle to setY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setY as text
%        str2double(get(hObject,'String')) returns contents of setY as a double


% --- Executes during object creation, after setting all properties.
function setY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setZ_Callback(hObject, eventdata, handles)
% hObject    handle to setZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setZ as text
%        str2double(get(hObject,'String')) returns contents of setZ as a double


% --- Executes during object creation, after setting all properties.
function setZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in setPosition.
function setPosition_Callback(hObject, eventdata, handles)
% hObject    handle to setPosition (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global socketID positioner1 positioner2 positioner3;  % call x

%% for x
xMove=str2double(get(handles.setX,'String'));  % absolute position of x

if xMove>12.5 || xMove<-12.5
    msgbox('X scale exceeded! Try another value!');
else
    [errorCode] = GroupMoveAbsolute(socketID, positioner1, xMove) ;
    if (errorCode ~= 0)
        disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
    end
end

%% for y
yMove=str2double(get(handles.setY,'String'));  % absolute position of x

if yMove>12.5 || yMove<-12.5
    msgbox('Y scale exceeded! Try another value!');
else
    [errorCode] = GroupMoveAbsolute(socketID, positioner2, yMove) ;
    if (errorCode ~= 0)
        disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
    end
end

%% for z
zMove=str2double(get(handles.setZ,'String'));  % absolute position of x
zMin=str2double(get(handles.zLimit,'String'));  % get z limit

if zMove>12.5 || zMove<zMin
    msgbox('Z scale exceeded! Try another value!');
else
    [errorCode] = GroupMoveAbsolute(socketID, positioner3, zMove) ;
    if (errorCode ~= 0)
        disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
    end
end


function zLimit_Callback(hObject, eventdata, handles)
% hObject    handle to zLimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of zLimit as text
%        str2double(get(hObject,'String')) returns contents of zLimit as a double


% --- Executes during object creation, after setting all properties.
function zLimit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zLimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in startClick.
function startClick_Callback(hObject, eventdata, handles)
% hObject    handle to startClick (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global socketID;  % for connection
global positioner1 positioner2 positioner3; % for controlling

[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner1, 1) ; % x
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    set(handles.xPosition,'String',num2str(currentPosition));
end
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner2, 1) ; % y
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    set(handles.yPosition,'String',num2str(currentPosition));
end
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner3, 1) ; % z
if errorCode~=0
    error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
else
    set(handles.zPosition,'String',num2str(currentPosition));
end
msgbox('connection successful!');

while ishandle(gcbo)
    [errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner1, 1) ; % x
    if errorCode~=0
        error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
    else
        set(handles.xPosition,'String',num2str(currentPosition));
    end
    [errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner2, 1) ; % y
    if errorCode~=0
        error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
    else
        set(handles.yPosition,'String',num2str(currentPosition));
    end
    [errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner3, 1) ; % z
    if errorCode~=0
        error(['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']);
    else
        set(handles.zPosition,'String',num2str(currentPosition));
    end
    pause(0.5);
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
global socketID;

TCP_CloseSocket(socketID) ;
disp('socket closed')
delete(hObject);
