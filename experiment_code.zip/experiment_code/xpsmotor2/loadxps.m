% Load the library
xps_load_drivers ;

%%
% Set connection parameters
IP = '10.102.32.182' ;
Port = 5001 ;
TimeOut = 60.0 ;
% Connect to XPS
socketID = TCP_ConnectToServer (IP, Port, TimeOut) ;
% Check connection
if (socketID < 0)
disp 'Connection to XPS failed, check IP & Port' ;
return ;
end
% Define the positioner
group1 = 'GROUP1' ;
positioner1 = 'GROUP1.POSITIONER' ;
group2 = 'GROUP2' ;
positioner2 = 'GROUP2.POSITIONER' ;
group3 = 'GROUP3' ;
positioner3 = 'GROUP3.POSITIONER' ;
