%%
% Load the library
xps_load_drivers ;

%%
% Set connection parameters
IP = '10.102.32.182' ;
Port = 5001 ;
TimeOut = 60.0 ;
% Connect to XPS
socketID = TCP_ConnectToServer (IP, Port, TimeOut) ;
% Check connection
if (socketID < 0)
disp 'Connection to XPS failed, check IP & Port' ;
return ;
end
% Define the positioner
group1 = 'GROUP1' ;
positioner1 = 'GROUP1.POSITIONER' ;
group2 = 'GROUP2' ;
positioner2 = 'GROUP2.POSITIONER' ;
group3 = 'GROUP3' ;
positioner3 = 'GROUP3.POSITIONER' ;



%% Make a move

[errorCode] = GroupMoveAbsolute(socketID, positioner1, 0) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
return ;
end

% Get current position
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner1, 1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']) ;
return ;
else
disp (['Positioner ' positioner1 ' is in position ' num2str(currentPosition)]) ;
end

[errorCode] = GroupMoveAbsolute(socketID, positioner2, 3) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
return ;
end

% Get current position
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner2, 1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']) ;
return ;
else
disp (['Positioner ' positioner2 ' is in position ' num2str(currentPosition)]) ;
end

[errorCode] = GroupMoveAbsolute(socketID, positioner3, 0) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupMoveAbsolute ! ']) ;
return ;
end

% Get current position
[errorCode, currentPosition] = GroupPositionCurrentGet(socketID, positioner3, 1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupPositionCurrentGet! ']) ;
return ;
else
disp (['Positioner ' positioner3 ' is in position ' num2str(currentPosition)]) ;
end
%% relative move;
[errorCode] = GroupMoveRelative(socketID, positioner3, 1) ;
%%
% Close connection
%{

TCP_CloseSocket(socketID) ;
disp('socket closed')

%}
%% used for initialization
%{

% Kill the group
[errorCode] = GroupKill(socketID, group1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupKill ! ']) ;
return ;
end
[errorCode] = GroupKill(socketID, group2) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupKill ! ']) ;
return ;
end
[errorCode] = GroupKill(socketID, group3) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupKill ! ']) ;
return ;
end
% Initialize the group
[errorCode] = GroupInitialize(socketID, group1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupInitialize ! ']) ;
return ;
end
[errorCode] = GroupInitialize(socketID, group2) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupInitialize ! ']) ;
return ;
end
[errorCode] = GroupInitialize(socketID, group3) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupInitialize ! ']) ;
return ;
end

% Home search
[errorCode] = GroupHomeSearch(socketID, group1) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupHomeSearch ! ']) ;
return ;
end

[errorCode] = GroupHomeSearch(socketID, group2) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupHomeSearch ! ']) ;
return ;
end

[errorCode] = GroupHomeSearch(socketID, group3) ;
if (errorCode ~= 0)
disp (['Error ' num2str(errorCode) ' occurred while doing GroupHomeSearch ! ']) ;
return ;
end


%}