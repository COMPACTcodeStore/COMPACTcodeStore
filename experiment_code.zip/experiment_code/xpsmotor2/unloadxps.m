TCP_CloseSocket(socketID) ;
disp('socket closed')