function zernike=spherical_zernike(size_x,size_y,zern_p,centerx,centery,radius)
%% define grid (MEMS size)
x = linspace(-1,1,2*radius) ;
[X,Y] = meshgrid(x,x);
[theta,r] = cart2pol(X,Y);
idx = r<=1;
%% generate Zernike polynomials
% p = 1:zern_max; %number of orders start from order 1
p=2*zern_p.*(zern_p+1);
z = zeros(size(X));
zernike=zeros(size_x,size_y,numel(p));
y = zernfun2(p,r(idx),theta(idx));
for k = 1:length(p)
    z(idx) = y(:,k);
    zernike(:,:,k)=circshift(padarray(z,[(size_x-size(z,1))/2 (size_y-size(z,2))/2]),[-(size_x/2-centery) -(size_y/2-centerx)]);
end