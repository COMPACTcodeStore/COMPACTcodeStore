%% add camera control;
vid = videoinput('winvideo', 1, 'Y800_640x480');
src = getselectedsource(vid);
src.GainMode = 'manual';
src.ExposureMode='manual';
src.Exposure = -4;
src.Gain = 4;
src.FrameRate = '52.3711';
%% SLM initialize
if ~libisloaded('Blink_C_wrapper')
    loadlibrary('Blink_C_wrapper.dll', 'Blink_C_wrapper.h');
end
% This loads the image generation functions
if ~libisloaded('ImageGen')
    loadlibrary('ImageGen.dll', 'ImageGen.h');
end
% Basic parameters for calling Create_SDK
bit_depth = 12;
num_boards_found = libpointer('uint32Ptr', 0);
constructed_okay = libpointer('int32Ptr', 0);
is_nematic_type = 1;
RAM_write_enable = 1;
use_GPU = 0;
max_transients = 10;
wait_For_Trigger = 0; % This feature is user-settable; use 1 for 'on' or 0 for 'off'
external_Pulse = 0;
timeout_ms = 5000;
% - In your program you should use the path to your custom LUT as opposed to linear LUT
lut_file = 'C:\Program Files\Meadowlark Optics\Blink OverDrive Plus\LUT Files\linear.LUT';
reg_lut = libpointer('string');
% Call the constructor
calllib('Blink_C_wrapper', 'Create_SDK', bit_depth, num_boards_found, constructed_okay, is_nematic_type, RAM_write_enable, use_GPU, max_transients, reg_lut);
% Convention follows that of C function return values: 0 is success, nonzero integer is an error
if constructed_okay.value ~= 0
    disp('Blink SDK was not successfully constructed');
    disp(calllib('Blink_C_wrapper', 'Get_last_error_message'));
    calllib('Blink_C_wrapper', 'Delete_SDK');
else
    board_number = 1;
    disp('Blink SDK was successfully constructed');
    fprintf('Found %u SLM controller(s)\n', num_boards_found.value);
    % load a LUT
    calllib('Blink_C_wrapper', 'Load_LUT_file',board_number, lut_file);
    height = calllib('Blink_C_wrapper', 'Get_image_height', board_number);
    width = calllib('Blink_C_wrapper', 'Get_image_width', board_number);
    %     WFC = libpointer('uint8Ptr', zeros(width*height,1));
    %     PixelValue = 0;
    %     calllib('ImageGen', 'Generate_Solid', WFC, width, height, PixelValue);
    %     WFC = reshape(WFC.Value, [width,height]);
end
%% import voltage array data;
load('C:\Users\bind-user\Desktop\930\voltagearray_fast.mat');
load('C:\Users\bind-user\Desktop\930\slmphase.mat');
%% compare;
outputphase=0;
% outputphase=0*aberration;
outputphase=angle(exp(1i*(circshift(outputphase,[0,0])-slmphase)))+1.1*pi;% shift minimum to above 0;
for k1=1:9
    for k2=1:15
        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
    end
end
vout=uint8(vout);
% Screen(window2, 'PutImage',vout);Screen(window2,'Flip');
calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
% pause(0.2);
pause(0.02);
% figure;q=getsnapshot(vid);imagesc(q-camera_background);colorbar;title(max(q(:)-camera_background));
% save([datafolder,'NOAOimage_',num2str(filen),'.mat'],'q');
%% add Gaussian aberration;
g=0;
gx1=570;
gy1=590;
% gx2=670;
% gy2=310;
% gx3=1100;
% gy3=300;
% gx4=1100;
% gy4=810;
gFWHM1=180;
% gFWHM2=180;
% gFWHM3=180;
% gFWHM4=180;
gr1=gFWHM1/(2*sqrt(log(2)));
% gr2=gFWHM2/(2*sqrt(log(2)));
% gr3=gFWHM3/(2*sqrt(log(2)));
% gr4=gFWHM4/(2*sqrt(log(2)));
[x,y]=meshgrid(1:1920,1:1152);
g=2*pi*exp(-((x-gx1).^2+(y-gy1).^2)/gr1^2);
% g=2*pi*exp(-((x-gx1).^2+(y-gy1).^2)/gr1^2)+2*pi*exp(-((x-gx2).^2+(y-gy2).^2)/gr2^2)+2*pi*exp(-((x-gx3).^2+(y-gy3).^2)/gr3^2)+2*pi*exp(-((x-gx4).^2+(y-gy4).^2)/gr4^2);
outputphase=angle(exp(1i*(g-slmphase)))+1.1*pi;% shift minimum to above 0;
for k1=1:9
    for k2=1:15
        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
    end
end
vout=uint8(vout);
% Screen(window2, 'PutImage',vout);Screen(window2,'Flip');
calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
% pause(0.2);
pause(0.02);
%% motor control;
%define motion vector;
ORi=[18.1869;15.8511;5.6697;];
p2=[18.1269; 15.8554+0.002;5.6681-0.003];
mv=p2-ORi;
mv=mv./(sqrt(sum(mv.*mv)))*0.001;% 1 micron as the unit;
%define origin;
moveby=(-4:3)*20;
zrange=moveby;zrange(1)=[];
% expN=[-2,-3,-3,-4,-7,-9,-6, -5, -4,-3]-1;
expN=[-3,-3,-4,-7,-9,-6, -5, -4,]-1;
data=[];
global s2 waitabit motorX motorY motorZ;
% start movement;
for q=1:length(moveby)
    currentP=moveby(q)*mv+ORi;
    src.Exposure =expN(q);
    motorX=currentP(1);
    if motorX>=0
        p=num2str(motorX,'%6.4f');
        fprintf(s2,['1pa+',p,';1ws;']);
    else
        p=num2str(-motorX,'%6.4f');
        fprintf(s2,['1pa-',p,';1ws;']);
    end
    pause(waitabit);
    
    motorY=currentP(2);
    if motorY>=0
        p=num2str(motorY,'%6.4f');
        fprintf(s2,['2pa+',p,';2ws;']);
    else
        p=num2str(-motorY,'%6.4f');
        fprintf(s2,['2pa-',p,';2ws;']);
    end
    pause(waitabit);
    
    motorZ=currentP(3);
    if motorZ>=0
        p=num2str(motorZ,'%6.4f');
        fprintf(s2,['3pa+',p,';3ws;']);
    else
        p=num2str(-motorZ,'%6.4f');
        fprintf(s2,['3pa-',p,';3ws;']);
    end
    pause(waitabit);
     pause (1);    
     q=getsnapshot(vid);
     data=cat(3, data, double(q));
end
data(:,:,1)=[];
%% review image stack;
for k=1:size(data,3);
    imagesc(data(:,:,k));
    drawnow;
    pause(1);
end
%% define the sampling and NA;
lambda=0.93;
NA=0.5;
n=1;
N=480;
xstep=0.1815;  %15*8.73/4;
x=(1:N)*xstep;
y=x;
[X,Y]=meshgrid(x,y);
dk=2*pi./(max(x)-min(x));
kx=(-N/2+1:N/2)*dk;
ky=kx;
[KX,KY]=meshgrid(kx,ky);
KR=sqrt(KX.^2+KY.^2);
KZ=sqrt((2*pi/lambda*n)^2-KX.^2-KY.^2);
kmask=0.*KX;
kmax=2*pi/lambda*NA;
kmin=2*pi/lambda*NA*0.0;
id=(KR<=kmax & KR>=kmin) | KR<=kmax*0.0;
%id=KR<=kmax & abs(KX)>=kmax*0.1 & abs(KY)<kmax*0.05;
%id=KR<=kmax & abs(KX)>=kmax*0.6 & abs(KY)<kmax*0.05;
%id=KR<=kmax & KR>kmax*0.88 & abs(KX)>=kmax*0.85 & abs(KX)<=kmax*0.9;
kmask(id)=1;
imagesc(kmask);
KZ=KZ.*kmask;
E=fftshift(fft2(kmask));
imagesc(x,y,abs(E).^2);
% I2=abs(E(N/2+1,:)).^2;
% f=fit(x(:),I2(:),'gauss1');
% plot(x,I2,x,f(x));title(['FWHM = ',num2str(f.c1*2*sqrt(log(2)))]);
%% define amplitude profile and phase aberration;
ampMask=exp(-KR.^2/kmax.^2);
phaseMask=(sin(KR/kmax*2*pi)*2*pi*0.3+sin(KX/kmax*2*pi)*0.7)*2;
EKaberration=kmask.*ampMask.*exp(1i*phaseMask);
%% data thresholding and normalization;
data2=[];
threshold=16;
shiftx=-2;
shifty=18;
for k=1:size(data,3);
    m=data(:,:,k);
    m=m-threshold;
    id=find(m<0);
    m(id)=0;
    m(:,[1:60, 541:640])=[];
    m=m./sum(m(:));
    m=circshift(m,[shifty, shiftx]);
    imagesc(m);colorbar;
    data2=cat(3, data2,m);
    drawnow;
    pause(1);
end

%% phase retrieval;
Idata=data2;
ampGuess=kmask;
phaseGuess=0.*kmask;
for loopN=1:50
    newEf=[];
    for q=1:length(zrange)
        z=zrange(q);
        Ef=ampGuess.*exp(1i*phaseGuess).*exp(1i*KZ*z);
        EGuess=fftshift(fft2(Ef));
        % from measurement;
        Eabs=sqrt(Idata(:,:,q));
        Eupdate=Eabs.*exp(1i*angle(EGuess));
        EfUpdate=ifft2(ifftshift(Eupdate)).*exp(1i*KZ*-z).*kmask;
        newEf=cat(3, newEf, EfUpdate);
        imagesc(abs(EfUpdate));drawnow;
    end
    newEf=mean(newEf,3);
    newEf=newEf.*kmask;
    ampGuess=abs(newEf);
    phaseGuess=angle(newEf);
    subplot(2,2,1);
    imagesc(angle(exp(1i*phaseMask)).*kmask);title('original phase');drawnow;
    subplot(2,2,2);
    imagesc(phaseGuess);title(['current phase amplitude for loop  ',num2str(loopN)]);drawnow;
    subplot(2,2,3);
    imagesc(ampMask.*kmask);title('original amplitude');drawnow;
    subplot(2,2,4);
    imagesc(ampGuess);title(['current pupil amplitude for loop  ',num2str(loopN)]);drawnow;
    colormap hsv;
end
%% add phase slop;
[a,b]=meshgrid(1:480,1:480);
phaseslop=a*0.16+b*0.11;
guess2=(phaseGuess+phaseslop).*kmask;
guess2=angle(exp(1i*guess2));
imagesc(guess2);colormap hsv;
%% no sign change, left right up down flip;
guess3=fliplr(flipud(guess2));
figure;imagesc(guess3);colormap hsv;
    %% projective image transformation;
tform = maketform('projective',[222  265; 228 215; 268 218;264 267],[ 640 810;  670  310;  1100 300; 1100 810]);
[guess5,xdata,ydata] = imtransform(unwrap_L2Norm(test2), tform);
imagesc(xdata, ydata, guess5);colormap hsv;
[x1,y1]=meshgrid(linspace(min(xdata), max(xdata), size(guess5,2)),linspace(min(ydata), max(ydata), size(guess5,1)));
[x2,y2]=meshgrid(1:1920,1:1152);
guess6=interp2(x1,  y1,guess5,  x2, y2);
imagesc(guess6); colormap hsv;
CenterX=860;
CenterY=590;
r=440;
x=1:size(guess6,2);
y=1:size(guess6,1);
[X,Y]=meshgrid(x,y);
mask=X.*0;
id=find((X-CenterX).^2+(Y-CenterY).^2<=r^2);
% id=find(abs(X-cx)<=r & abs(Y-cy)<=3*r);
mask(id)=1;
guess7=guess6.*mask;
imagesc(guess7); colormap hsv;
%% resize and recenter;
% guess4=guess3(200:280,200:280);
% guess5=unwrap_L2Norm(guess4);
% guess6=imresize(guess5,[880,880]);
% CenterX=860;
% CenterY=590;
%% apply correction;
outputphase=zeros(1152,1920);
% outputphase(CenterY-size(guess7,2)/2:CenterY+(size(guess7,2)/2-1),CenterX-size(guess7,1)/2:CenterX+(size(guess7,1)/2-1))=guess7;
outputphase=guess7;
outputphase=angle(exp(1i*(outputphase-slmphase)))+1.1*pi;% shift minimum to above 0;
for k1=1:9
    for k2=1:15
        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
    end
end
vout=uint8(vout);
% Screen(window2, 'PutImage',vout);Screen(window2,'Flip');
calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
% pause(0.2);
pause(0.02);
%% compare;
outputphase=0;
% outputphase=0*aberration;
outputphase=angle(exp(1i*(circshift(outputphase,[0,0])-slmphase)))+1.1*pi;% shift minimum to above 0;
for k1=1:9
    for k2=1:15
        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
    end
end
vout=uint8(vout);
% Screen(window2, 'PutImage',vout);Screen(window2,'Flip');
calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
% pause(0.2);
pause(0.02);
% figure;q=getsnapshot(vid);imagesc(q-camera_background);colorbar;title(max(q(:)-camera_background));
% save([datafolder,'NOAOimage_',num2str(filen),'.mat'],'q');