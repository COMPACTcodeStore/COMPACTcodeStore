cx=28;
cy=23;
r=20;
finalphase2=zeros(50);
finalphase2(1:48,:)=finalphase;
x=1:size(finalphase2,2);
y=1:size(finalphase2,1);
[X,Y]=meshgrid(x,y);
mask=X.*0;
id=find((X-cx).^2+(Y-cy).^2<=r^2);
mask(id)=1;
filteredphase=circshift(finalphase2.*mask,[3 -2]);
figure;imagesc(filteredphase);colormap hsv
%%
id=find((X-26).^2+(Y-26).^2>r^2);
filteredphase(id)=2.3;

filteredphase=Expand(filteredphase, 20, 20);

figure;imagesc(filteredphase);colormap hsv
%%
[phase,mask]= unwrap_L2Norm(filteredphase);
%% make zernike polynomials
zern_p=[];
for j=2:25
    zern_p=[zern_p,2*j*(j+1)];
end
% zern_p=[zern_p,3,5:11,13:23,23:27];
zernike=make_zernike2(zern_p,500,500,400); % generate the zernike,start from mode 1
%%
pol=zeros(24,1);
for j=1:22
    pol(j)=sum(sum(zernike(:,:,j).*phase));
end
figure;plot(pol);
%%
x=0:20;
y=unwrap(finalphase(22,28:48));
fit_finalphase=fit(x.',y.','poly4');
%%
outputphase=Expand(finalphase, 1000/50, 1152/48);
cx=545;
cy=493;
r=460;
x=1:size(outputphase,2);
y=1:size(outputphase,1);
[X,Y]=meshgrid(x,y);
mask=X.*0;
id=find((X-cx).^2+(Y-cy).^2<=r^2);
mask(id)=1;
filteredphase=outputphase.*mask;
figure;imagesc(filteredphase);colormap hsv