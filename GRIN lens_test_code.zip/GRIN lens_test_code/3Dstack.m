%%
IMG_stack=zeros(512,4600,2500);
for rot_angle=168:8:280
    for wd=100:5:400
        img=imread(['egfp_',num2str(rot_angle*100),'_',num2str(wd),'.tif']);
        for ii=1:512
            for jj=1:512
                y=jj;
                x=int16((500+wd)*sind(rot_angle-224)/0.35+2300+(ii-256)*cosd(rot_angle-224));
                z=int16((500+wd)*cosd(rot_angle-224)/0.35-900+(ii-256)*cosd(rot_angle-224))+90;
%                 neighbour_direction
                if IMG_stack(y,x,z)<img(jj,ii)
                    IMG_stack(y,x,z)=img(jj,ii);
                end
%                 if IMG_stack(y,x,z+1)<0.8*img(jj,ii)
%                     IMG_stack(y,x,z+1)=0.8*img(jj,ii);
%                 end
%                 if IMG_stack(y,x,z-1)<0.8*img(jj,ii)
%                     IMG_stack(y,x,z-1)=0.8*img(jj,ii);
%                 end
%                 if IMG_stack(y,x,z+2)<0.5*img(jj,ii)
%                     IMG_stack(y,x,z+2)=0.5*img(jj,ii);
%                 end
%                 if IMG_stack(y,x,z-2)<0.5*img(jj,ii)
%                     IMG_stack(y,x,z-2)=0.5*img(jj,ii);
%                 end
%                 if IMG_stack(y,x,z+3)<0.3*img(jj,ii)
%                     IMG_stack(y,x,z+3)=0.3*img(jj,ii);
%                 end
%                 if IMG_stack(y,x,z-3)<0.3*img(jj,ii)
%                     IMG_stack(y,x,z-3)=0.3*img(jj,ii);
%                 end
            end
        end
    end
    rot_angle
end
%%
for kk=1:2500
    imwrite(IMG_stack(:,:,kk)/32768,'test.tif','WriteMode','append');
    kk
end