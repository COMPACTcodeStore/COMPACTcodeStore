%% SLM initialize
if ~libisloaded('Blink_C_wrapper')
    loadlibrary('Blink_C_wrapper.dll', 'Blink_C_wrapper.h');
end
% This loads the image generation functions
if ~libisloaded('ImageGen')
    loadlibrary('ImageGen.dll', 'ImageGen.h');
end
% Basic parameters for calling Create_SDK
bit_depth = 12;
num_boards_found = libpointer('uint32Ptr', 0);
constructed_okay = libpointer('int32Ptr', 0);
is_nematic_type = 1;
RAM_write_enable = 1;
use_GPU = 0;
max_transients = 10;
wait_For_Trigger = 0; % This feature is user-settable; use 1 for 'on' or 0 for 'off'
external_Pulse = 0;
timeout_ms = 5000;
% - In your program you should use the path to your custom LUT as opposed to linear LUT
lut_file = 'C:\Program Files\Meadowlark Optics\Blink OverDrive Plus\LUT Files\linear.LUT';
reg_lut = libpointer('string');
% Call the constructor
calllib('Blink_C_wrapper', 'Create_SDK', bit_depth, num_boards_found, constructed_okay, is_nematic_type, RAM_write_enable, use_GPU, max_transients, reg_lut);
% Convention follows that of C function return values: 0 is success, nonzero integer is an error
if constructed_okay.value ~= 0
    disp('Blink SDK was not successfully constructed');
    disp(calllib('Blink_C_wrapper', 'Get_last_error_message'));
    calllib('Blink_C_wrapper', 'Delete_SDK');
else
    board_number = 1;
    disp('Blink SDK was successfully constructed');
    fprintf('Found %u SLM controller(s)\n', num_boards_found.value);
    % load a LUT
    calllib('Blink_C_wrapper', 'Load_LUT_file',board_number, lut_file);
    height = calllib('Blink_C_wrapper', 'Get_image_height', board_number);
    width = calllib('Blink_C_wrapper', 'Get_image_width', board_number);
    %     WFC = libpointer('uint8Ptr', zeros(width*height,1));
    %     PixelValue = 0;
    %     calllib('ImageGen', 'Generate_Solid', WFC, width, height, PixelValue);
    %     WFC = reshape(WFC.Value, [width,height]);
end
%%
vid = videoinput('winvideo', 2, 'Y800_640x480');
src = getselectedsource(vid);
src.GainMode = 'manual';
src.ExposureMode='manual';
src.Exposure = -8;
src.Gain = 4;
src.FrameRate = '52.3711';
vid.ROIPosition = [100 260 160 160];
%% import voltage array data;
load('C:\Users\bind-user\Desktop\930\voltagearray_fast.mat');
load('C:\Users\bind-user\Desktop\930\slmphase.mat');
%% make zernike polynomials
% zern_max=35; % max order of zernike
zern_p=[];
% for j=1:25
%     zern_p=[zern_p,2*j*(j+1)];
% end
zern_p=[3,5:11,13:39,41:59,61:83,zern_p];
% zern_p=[3,5:11,13:39,zern_p];
zernike=make_zernike(zern_p,780,480,500); % generate the zernike,start from mode 1
%%
% image_path='H:\COMPACT\data\20190322\bead1\';
% mkdir(image_path)
Nxpixels=160;
Nypixels=160;
N=1;
pausetime=0.08; %pause for SLM
basephase=aberration;
metric=[];
coeff_zern=[];
threshold=100;
fit_threshold=0.75;
amp_lim=pi*3;
amp_N=7;
amplitude=linspace(-amp_lim,amp_lim,amp_N);
metric_option=2;%option 1---sum of the total pixles, option 2---sum of high frequency pixels,
if metric_option==2
    MASKF=ones(Nypixels,Nxpixels);
    min_k= 6;
    max_k= 120;
    x=linspace(-1,1,Nxpixels)*Nxpixels/2;
    y=linspace(-1,1,Nypixels)*Nypixels/2;
    [X,Y]=meshgrid(x,y);
    MASKF((X.^2+Y.^2)<min_k^2)=0;
    MASKF((X.^2+Y.^2)>max_k^2)=0;
    figure(234);imagesc(MASKF)
end
zernike_modes=[1:size(zernike,3)];% select the zernike mode for AO
% exp_num=[-11*ones(1,28),-11*ones(1,20)];
checkid=1;
counterN=1;
correction=zeros(1152,1920);
SaveImageBuffer=zeros(Nypixels,Nxpixels,(N*size(zernike,3)),numel(amplitude));
% hSI.startLoop();pause(5)
filecounter=0;
for round_id=1:N    %iteration #
    for zern_id=zernike_modes%size(zernike,3)
        metricAll=[];
        amplitudeAll=[];
        while(checkid)
            filecounter=filecounter+1;
            for amp_id=1:numel(amplitude)
                totalwavefront=zernike(:,:,zern_id)*amplitude(amp_id)+correction+basephase;  %apply re order Zernike with changing amplitude
                outputphase=angle(exp(1i*totalwavefront))+1.1*pi;% shift minimum to above 0;
                for k1=1:9
                    for k2=1:15
                        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
                        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
                        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
                    end
                end
                vout=uint8(vout);
                calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
                calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
%                 src.Exposure=exp_num(zern_id);
                pause(pausetime);
                BUFF=double(getsnapshot(vid));
                SaveImageBuffer(:,:,zern_id,amp_id)=BUFF;
                BUFF_background=mean(mean(BUFF(1:10,1:10)));
                BUFF=BUFF-BUFF_background;
                BUFF(BUFF<threshold)=0;
                max(BUFF(:))
                if metric_option==1
                    metric(amp_id)=sum(BUFF(:)); % sum of the whole pixles
                elseif metric_option==2
                    metric(amp_id)=sum(sum(abs(fftshift(fft2(double(BUFF)))).*MASKF));
                else
                    metric(amp_id)=sum(BUFF(:)); % sum of the whole pixles
                end
            end
            metricAll=[metricAll; metric(:)];
            amplitudeAll=[amplitudeAll;amplitude(:)];
            %fresult=fit(amplitudeAll(:),metricAll(:),'gauss1');
            %plot(amplitudeAll, metricAll,' bo', amplitudeAll,fresult.a1*exp(-((amplitudeAll-fresult.b1)./fresult.c1).^2),' rx' );
            % Set up fittype and options.
            ft = fittype( 'gauss1' );
            opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
            opts.DiffMinChange = 0.01;
            opts.Lower = [min(metricAll) min(amplitudeAll)-2*pi (max(amplitudeAll)-min(amplitudeAll))/5];
            opts.Upper = [max(metricAll)*2 max(amplitudeAll)+2*pi (max(amplitudeAll)-min(amplitudeAll))*5];
            % opts.StartPoint = [max(y) mean(y) (max(y)-min(y))/2];
            opts.TolFun = 0.01;
            opts.TolX = 0.01;
            % Fit model to data.
            [fitresult, gof] = fit( amplitudeAll(:), metricAll(:), ft, opts );
            % Plot fit with data.
            h=figure(999);
            subplot(1,2,1)
            plot( fitresult, amplitudeAll(:), metricAll(:) );
            legend off;
            %legend( h, 'y vs. x', 'untitled fit 1', 'Location', 'NorthEast' );
            %title(['time ',num2str(t),'  SSE ',num2str(gof.sse)]);
            % Label axes
            xlabel amplitude
            ylabel metric
            title(['zern mode number ',num2str(zern_id),' rsquare ',num2str(gof.rsquare)]);
            drawnow;
            % grid on
            % check if the center is outside the range
            if gof.rsquare>fit_threshold
                max_point=fitresult.b1;
            else
                [maxvalue,maxid]=max(metricAll);
                max_point=amplitudeAll(maxid);
            end
            if max_point>=max(amplitudeAll)
                amplitude=amplitude-min(amplitude)+max(amplitudeAll);
                checkid=1;
                counterN=counterN+1;
            elseif max_point<=min(amplitudeAll)
                amplitude=amplitude-max(amplitude)+min(amplitudeAll);
                checkid=1;
                counterN=counterN+1;
            else
                checkid=0;
                counterN=1;
            end
            if counterN>=5
                max_point=0;
                checkid=0;
            end
            %             disp(counterN);
            counterN=counterN+1;
            coeff_zern(zern_id)=max_point;
            fit_max(zern_id)=fitresult.a1;
            
        end
        correction=correction+zernike(:,:,zern_id).*max_point;
        checkid=1;
        counterN=1;
        amplitude=linspace(-amp_lim,amp_lim,amp_N);
        subplot(1,2,2)
        imagesc(correction);
        colormap jet;colorbar;drawnow;
    end
    totalwavefront=correction+basephase;
    outputphase=angle(exp(1i*totalwavefront))+1.1*pi;% shift minimum to above 0;
    for k1=1:9
        for k2=1:15
            phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
            vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
            vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
        end
    end
    vout=uint8(vout);
    calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
    calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
    pause(pausetime);
end
figure;
subplot(1,2,1);plot(coeff_zern);title('zernike coeff')
subplot(1,2,2);plot(fit_max);title('max fitting value')

%% system correction
outputphase=angle(exp(1i*totalwavefront))+1.1*pi;% shift minimum to above 0;
for k1=1:9
    for k2=1:15
        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
    end
end
vout=uint8(vout);
calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
pause(pausetime);
camera_background=15;
figure;q=getsnapshot(vid);imagesc(q-camera_background);colorbar;title(max(q(:)-camera_background));
%% compare;
outputphase=-1*slmphase;
outputphase=angle(exp(1i*outputphase))+1.1*pi;% shift minimum to above 0;
for k1=1:9
    for k2=1:15
        phaseblock=outputphase((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128);
        vblock=voltagearray(k1,k2,1)*phaseblock.^6 + voltagearray(k1,k2,2)*phaseblock.^5 + voltagearray(k1,k2,3)*phaseblock.^4 + voltagearray(k1,k2,4)*phaseblock.^3+voltagearray(k1,k2,5)*phaseblock.^2+voltagearray(k1,k2,6)*phaseblock.^1+voltagearray(k1,k2,7);
        vout((k1-1)*128+1:(k1-1)*128+128,(k2-1)*128+1:(k2-1)*128+128)=vblock;
    end
end
vout=uint8(vout);
calllib('Blink_C_wrapper', 'Write_image', board_number,flip(vout'), width*height, wait_For_Trigger, external_Pulse, timeout_ms);
calllib('Blink_C_wrapper', 'ImageWriteComplete', board_number, timeout_ms);
camera_background=15;
figure;q=getsnapshot(vid);imagesc(q-camera_background);colorbar;title(max(q(:)-camera_background));
%%
save([image_path,'phase0_copy.mat'],'correction','totalwavefront');
%%
cd(image_path);
delete *.tif