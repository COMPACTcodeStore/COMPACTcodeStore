data_prefix='dff1_';
for ii=6:6
    deltaFdata = xlsread('deltaFoverF.xlsx');
    save([data_prefix,num2str(ii),'.mat'],'deltaFdata')
    clear deltaFdata
end