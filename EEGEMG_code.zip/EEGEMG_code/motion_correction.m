%%
% Folder_list={'Data1';'Data2';'Data3';'Data4'};
% File_prefix_list={'EEG_0107';'EEG_0107_002';'EEG_0106_001';'EEG_0106_002'};
Folder_list={'Data1'};
File_prefix_list={'EEG_0107'};
File_number=[1,2,3,4,5,6];
base_folder='C:\Users\labadmin\Desktop\COMPACT EEGEMG';
file_N=100;
[optimizer, metric] = imregconfig('multimodal');
for NN=1:size(Folder_list,1)
    current_folder=[base_folder,'\',char(Folder_list(NN)),'\'];
    current_prefix=char(File_prefix_list(NN));
%     FileTif=[current_folder,current_prefix,'_',num2str(File_number+1,'%.3u'),'.tif'];
%     InfoImage=imfinfo(FileTif);
%     mImage=InfoImage(1).Width;
%     nImage=InfoImage(1).Height;
%     NumberImages=length(InfoImage);
%     m=zeros(nImage,mImage,NumberImages,'uint16');
%     TifLink = Tiff(FileTif, 'r');
%     for q=1:NumberImages
%         TifLink.setDirectory(q);
%         m(:,:,q)=TifLink.read();
%     end
%     TifLink.close();
%     warning off;
%     
%     img0=max(m,[],3);
%     img0=imresize(img0,[128, 512]);
    
    for nn=File_number
        FileTif=[current_folder,current_prefix,'_',num2str(nn,'%.3u'),'.tif'];
        InfoImage=imfinfo(FileTif);
        mImage=InfoImage(1).Width;
        nImage=InfoImage(1).Height;
        NumberImages=length(InfoImage);
        m=zeros(nImage,mImage,NumberImages,'uint16');
        TifLink = Tiff(FileTif, 'r');
        for q=1:NumberImages
            TifLink.setDirectory(q);
            m(:,:,q)=TifLink.read();
        end
        TifLink.close();
        warning off;
        
        for ll=1:file_N
            for kk=NumberImages/file_N*(ll-1)+1:NumberImages/file_N*ll
                moving_reg = imregister(m(:,:,kk),img0,'translation',optimizer,metric);
                imwrite(moving_reg,[current_folder,current_prefix,'_',num2str(nn,'%.3u'),'_',num2str(ll),'.tif'],'WriteMode','append');
                disp([current_folder,':',current_prefix,'_',num2str(nn,'%.3u'),':',num2str(kk)])
            end
        end
    end
end