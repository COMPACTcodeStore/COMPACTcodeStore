%% trace and heatmap
frequency_resolution=0.01;
frequency_number=1/frequency_resolution*5e3-1;
frequency_list=[0.1,3.5;4,7;8,13;14,30;30,59];
ff=1;
frequency_range_min=frequency_list(ff,1);
frequency_range_max=frequency_list(ff,2);
data_number=2;
file_number=1;
ii=2;
time_min=500;
time_max=1000;

time_min_all=(ii-1)*1000+time_min;
time_max_all=(ii-1)*1000+time_max;

time_all=(time_max-time_min)/5000*371.2;

file_name=['data',num2str(data_number),'_',num2str(file_number)];
load([file_name,'.mat']);
load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
uiopen([file_name,'.fig'],1);
h=gcf;
trace_data=getimage(h);
trace_data=trace_data(:,time_min_all:time_max_all);
close(h);

deltaFdata=deltaFdata(time_min_all:time_max_all,:);

EEG=EEG((time_min_all-1)*371.2+1:time_max_all*371.2);
EMG=EMG((time_min_all-1)*371.2+1:time_max_all*371.2);
s_EEG=spectrogram(EEG,512,141,frequency_number,5e3);


dff_sum=sum(deltaFdata');


h=figure;

subplot(5,1,1);
time=linspace(0,time_all,size(EEG,1));
plot(time,EEG);
axis tight
title(['f min:',num2str(frequency_range_min),';f max:',num2str(frequency_range_max)]);

subplot(5,1,2);
EEG_freq_img=flipud(abs(s_EEG((frequency_range_min/frequency_resolution):(frequency_range_max/frequency_resolution),:)));
imagesc(EEG_freq_img/(max(EEG_freq_img(:))));
colorbar
axis off

subplot(5,1,3);
imagesc(trace_data);
colorbar
axis off

subplot(5,1,4);
time=linspace(0,time_all,size(dff_sum,2));
plot(time,dff_sum/max(dff_sum(:)));
axis tight

subplot(5,1,5);
time=linspace(0,time_all,size(EMG,1));
plot(time,EMG);
axis tight

ha=get(gcf,'children');
colormap(ha(3),jet)
colormap(ha(4),jet)
colormap(ha(5),hot)
colormap(ha(6),hot)
%% scatter plot
EEG_freq_img=imresize(EEG_freq_img,[size(EEG_freq_img,1) size(dff_sum,2)]);
figure;
plot(sum(EEG_freq_img),dff_sum/max(dff_sum(:)),'.k');
xlim([0 max(sum(EEG_freq_img))]);
% ylim([0 max(dff_sum/max(dff_sum(:)))]);
%% trace and heatmap V2
data_number=3;
file_number=2;
ii=4;
time_min=200;
time_max=700;

time_min_all=(ii-1)*1000+time_min;
time_max_all=(ii-1)*1000+time_max;

time_all=(time_max-time_min)/5000*371.2;

file_name=['data',num2str(data_number),'_',num2str(file_number)];
load([file_name,'.mat']);
load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
uiopen([file_name,'.fig'],1);
h=gcf;
trace_data=getimage(h);
trace_data=trace_data(:,time_min_all:time_max_all);
close(h);

deltaFdata=deltaFdata(time_min_all:time_max_all,:);

EEG=EEG((time_min_all-1)*371.2+1:time_max_all*371.2);
EMG=EMG((time_min_all-1)*371.2+1:time_max_all*371.2);



for nn=1:size(trace_data,1)
    neuron_data=trace_data(nn,:);
    neuron_data=(neuron_data-min(neuron_data))/(max(neuron_data)-min(neuron_data));
    trace_data(nn,:)=neuron_data;
end

for nn=1:size(deltaFdata,2)
    neuron_data=deltaFdata(:,nn);
    neuron_data=(neuron_data-min(neuron_data))/(max(neuron_data)-min(neuron_data));
    deltaFdata(:,nn)=neuron_data;
end
dff_sum=sum(deltaFdata');
dff_sum=(dff_sum-min(dff_sum))/(max(dff_sum)-min(dff_sum));
h=figure;

subplot(4,1,1);
time=linspace(0,time_all,size(EEG,1));
plot(time,EEG);
axis tight

subplot(4,1,2);
imagesc(trace_data);
colorbar
axis off

subplot(4,1,3);
time=linspace(0,time_all,size(dff_sum,2));
plot(time,dff_sum);
axis tight

subplot(4,1,4);
time=linspace(0,time_all,size(EMG,1));
plot(time,EMG);
axis tight
mean_value=mean(EMG);
ylim([-200+mean_value 200+mean_value])

ha=get(gcf,'children');
colormap(ha(3),jet)
colormap(ha(4),jet)
% colormap(ha(5),hot)
% colormap(ha(6),hot)