fs=5000;
threshold=0.2;
EEG_size=size(EEG,1);
fill_number=round(EEG_size/10);
EEG=[EEG(1:fill_number);EEG;EEG(1:fill_number)];
f = fs*(-size(EEG,1)/2:size(EEG,1)/2-1)/size(EEG,1);
%%
Fs = 5000;                                            % Sampling Frequency
Fn = Fs/2;                                              % Nyquist Frequency
Wp = 4/Fn;                                        % Passband Frequencies (Normalized)
Ws = 4.1/Fn;                                        % Stopband Frequencies (Normalized)
Rp = 10;                                                % Passband Ripple (dB)
Rs = 50;                                                % Stopband Ripple (dB)
[n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
[c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
[sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
% freqz(sosbp, 2^16, Fs)

delta_wave = filtfilt(sosbp, gbp, EEG);
%%
Fs = 5000;                                            % Sampling Frequency
Fn = Fs/2;                                              % Nyquist Frequency
Wp = [4 8]/Fn;                                        % Passband Frequencies (Normalized)
Ws = [3.9 8.1]/Fn;                                        % Stopband Frequencies (Normalized)
Rp = 10;                                                % Passband Ripple (dB)
Rs = 50;                                                % Stopband Ripple (dB)
[n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
[c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
[sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
% freqz(sosbp, 2^16, Fs)

theta_wave = filtfilt(sosbp, gbp, EEG-delta_wave);
%%
Fs = 5000;                                            % Sampling Frequency
Fn = Fs/2;                                              % Nyquist Frequency
Wp = [8 13]/Fn;                                        % Passband Frequencies (Normalized)
Ws = [7.9 13.1]/Fn;                                        % Stopband Frequencies (Normalized)
Rp = 10;                                                % Passband Ripple (dB)
Rs = 50;                                                % Stopband Ripple (dB)
[n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
[c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
[sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
% freqz(sosbp, 2^16, Fs)

alpha_wave = filtfilt(sosbp, gbp, EEG-delta_wave-theta_wave);
%%
Fs = 5000;                                            % Sampling Frequency
Fn = Fs/2;                                              % Nyquist Frequency
Wp = [13 30]/Fn;                                        % Passband Frequencies (Normalized)
Ws = [12.9 30.1]/Fn;                                        % Stopband Frequencies (Normalized)
Rp = 10;                                                % Passband Ripple (dB)
Rs = 50;                                                % Stopband Ripple (dB)
[n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
[c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
[sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
% freqz(sosbp, 2^16, Fs)

beta_wave = filtfilt(sosbp, gbp, EEG-delta_wave-theta_wave-alpha_wave);
%%
Fs = 5000;                                            % Sampling Frequency
Fn = Fs/2;                                              % Nyquist Frequency
Wp = [30 2499.8]/Fn;                                        % Passband Frequencies (Normalized)
Ws = [29.9 2499.9]/Fn;                                        % Stopband Frequencies (Normalized)
Rp = 10;                                                % Passband Ripple (dB)
Rs = 50;                                                % Stopband Ripple (dB)
[n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
[c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
[sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
% freqz(sosbp, 2^16, Fs)

gamma_wave = filtfilt(sosbp, gbp, EEG-delta_wave-theta_wave-alpha_wave-beta_wave);
%%
res=EEG-delta_wave-theta_wave-alpha_wave-beta_wave-gamma_wave;
while max(res(fill_number+1:EEG_size+fill_number))>threshold
    %%
    Fs = 5000;                                            % Sampling Frequency
    Fn = Fs/2;                                              % Nyquist Frequency
    Wp = 4/Fn;                                        % Passband Frequencies (Normalized)
    Ws = 4.1/Fn;                                        % Stopband Frequencies (Normalized)
    Rp = 10;                                                % Passband Ripple (dB)
    Rs = 50;                                                % Stopband Ripple (dB)
    [n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
    [c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
    [sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
    delta_res = filtfilt(sosbp, gbp, res);

    Fs = 5000;                                            % Sampling Frequency
    Fn = Fs/2;                                              % Nyquist Frequency
    Wp = [4 8]/Fn;                                        % Passband Frequencies (Normalized)
    Ws = [3.9 8.1]/Fn;                                        % Stopband Frequencies (Normalized)
    Rp = 10;                                                % Passband Ripple (dB)
    Rs = 50;                                                % Stopband Ripple (dB)
    [n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
    [c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
    [sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
    theta_res = filtfilt(sosbp, gbp, res);

    Fs = 5000;                                            % Sampling Frequency
    Fn = Fs/2;                                              % Nyquist Frequency
    Wp = [8 13]/Fn;                                        % Passband Frequencies (Normalized)
    Ws = [7.9 13.1]/Fn;                                        % Stopband Frequencies (Normalized)
    Rp = 10;                                                % Passband Ripple (dB)
    Rs = 50;                                                % Stopband Ripple (dB)
    [n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
    [c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
    [sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
    alpha_res = filtfilt(sosbp, gbp, res);

    Fs = 5000;                                            % Sampling Frequency
    Fn = Fs/2;                                              % Nyquist Frequency
    Wp = [13 30]/Fn;                                        % Passband Frequencies (Normalized)
    Ws = [12.9 30.1]/Fn;                                        % Stopband Frequencies (Normalized)
    Rp = 10;                                                % Passband Ripple (dB)
    Rs = 50;                                                % Stopband Ripple (dB)
    [n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
    [c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
    [sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
    beta_res = filtfilt(sosbp, gbp, res);
    
    Fs = 5000;                                            % Sampling Frequency
    Fn = Fs/2;                                              % Nyquist Frequency
    Wp = [30 2499.8]/Fn;                                        % Passband Frequencies (Normalized)
    Ws = [29.9 2499.9]/Fn;                                        % Stopband Frequencies (Normalized)
    Rp = 10;                                                % Passband Ripple (dB)
    Rs = 50;                                                % Stopband Ripple (dB)
    [n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                         % Filter Order
    [c,b,a] = cheby2(n,Rs,Ws);                              % Filter Design
    [sosbp,gbp] = zp2sos(c,b,a);                            % Convert To Second-Order-Section For Stability
    gamma_res = filtfilt(sosbp, gbp, res);

    
    delta_wave=delta_wave+delta_res;
    theta_wave=theta_wave+theta_res;
    alpha_wave=alpha_wave+alpha_res;
    beta_wave=beta_wave+beta_res;
    gamma_wave=gamma_wave+gamma_res;
    
    res=EEG-delta_wave-theta_wave-alpha_wave-beta_wave-gamma_wave;
    max(res(fill_number+1:EEG_size+fill_number))
end
%%
time=linspace(0,size(EEG,1)/fs,size(EEG,1));
figure;
subplot(7,1,1);
plot(time,EEG);
title('raw EEG');
axis tight
subplot(7,1,2);
plot(time,delta_wave);
title('delta');
axis tight
% ylim([-150 150])
subplot(7,1,3);
plot(time,theta_wave);
title('theta');
axis tight
% ylim([-150 150])
subplot(7,1,4);
plot(time,alpha_wave);
title('alpha');
axis tight
% ylim([-150 150])
subplot(7,1,5);
plot(time,beta_wave);
title('beta');
axis tight
% ylim([-150 150])
subplot(7,1,6);
plot(time,gamma_wave);
title('gamma');
axis tight
% ylim([-150 150])
subplot(7,1,7);
plot(time,res);
title('residual');
axis tight
% ylim([-150 150])