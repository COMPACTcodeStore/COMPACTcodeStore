clear;clc;
cd('C:\Users\labadmin\Desktop\COMPACT EEGEMG\EEGdata_timepoint');

data_number=1;
file_number=6;

frequency_resolution=0.1;
frequency_number=1/frequency_resolution*5e3-1;
frequency_range_min=8;
frequency_range_max=13;
file_name=['data',num2str(data_number),'_',num2str(file_number)];
load([file_name,'.mat']);
load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
uiopen([file_name,'.fig'],1);
h=gcf;
trace_data=getimage(h);
dff_sum=sum(deltaFdata');
close(h);
s_EEG=spectrogram(EEG,2048,193,frequency_number,5e3);
% s_EMG=spectrogram(EMG,2048,193,1e4-1,5e3);
scrsz = get(groot,'ScreenSize');

h=figure('Position',[1 scrsz(4)/4 scrsz(3) scrsz(4)/2]);
subplot(5,1,1);
time=linspace(1,5000,size(EEG,1));
plot(time,EEG);
set(gca,'XAxisLocation','top');
% axis off
axis tight
ylim([-200 200])
subplot(5,1,2);
imagesc(flipud(abs(s_EEG((frequency_range_min/frequency_resolution):(frequency_range_max/frequency_resolution),:))));
axis off
subplot(5,1,3);
imagesc(trace_data);
axis off
subplot(5,1,4);
plot(dff_sum)
axis off
axis tight
subplot(5,1,5);
time=linspace(1,5000,size(EMG,1));
plot(time,EMG);
% axis off
axis tight
ylim([-200 200])

ha=get(gcf,'children');
set(ha(1),'position',[0.02    0.04    0.97    0.2])
set(ha(2),'position',[0.02    0.25   0.97   0.2])
set(ha(3),'position',[0.02    0.45    0.97    0.2])
set(ha(4),'position',[0.02    0.65    0.97    0.15])
set(ha(5),'position',[0.02    0.805    0.97   0.15])

% colormap(ha(2),hot)
colormap(ha(3),jet)
colormap(ha(4),hot)

%%
frequency_resolution=0.1;
frequency_number=1/frequency_resolution*5e3-1;
frequency_list=[0.1,3.5;4,7;8,13;14,30;30,59];
for ff=1:size(frequency_list,1)
    frequency_range_min=frequency_list(ff,1);
    frequency_range_max=frequency_list(ff,2);
    for data_number=2:4
        for file_number=1:6
            file_name=['data',num2str(data_number),'_',num2str(file_number)];
            load([file_name,'.mat']);
            load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
            uiopen([file_name,'.fig'],1);
            h=gcf;
            trace_data=getimage(h);
            close(h);
            s_EEG=spectrogram(EEG,2048,193,frequency_number,5e3);
            dff_sum=sum(deltaFdata');
            for ii=1:5
                scrsz = get(groot,'ScreenSize');
                
                h=figure('Position',[1 scrsz(4)/4 scrsz(3) scrsz(4)/2]);
                subplot(5,1,1);
                time=linspace((ii-1)*1000+1,ii*1000,size(EEG,1)/5);
                plot(time,EEG(((ii-1)*1000*371.2)+1:(ii*1000*371.2)));
                set(gca,'XAxisLocation','top');
                axis tight
                ylim([-200 200])
                subplot(5,1,2);
                imagesc(flipud(abs(s_EEG((frequency_range_min/frequency_resolution):(frequency_range_max/frequency_resolution),((ii-1)*1000/5)+1:(ii*1000/5)))));
                axis off
                subplot(5,1,3);
                imagesc(trace_data(:,((ii-1)*1000)+1:(ii*1000)));
                axis off
                subplot(5,1,4);
                plot(dff_sum(((ii-1)*1000)+1:(ii*1000)));
                axis off
                axis tight
                subplot(5,1,5);
                
                plot(time,EMG(((ii-1)*1000*371.2)+1:(ii*1000*371.2)));
                axis tight
                ylim([-200 200])
                
                ha=get(gcf,'children');
                set(ha(1),'position',[0.02    0.04    0.97    0.2])
                set(ha(2),'position',[0.02    0.25   0.97   0.2])
                set(ha(3),'position',[0.02    0.45    0.97    0.2])
                set(ha(4),'position',[0.02    0.65    0.97    0.15])
                set(ha(5),'position',[0.02    0.805    0.97   0.15])
                
                colormap(ha(3),jet)
                colormap(ha(4),hot)
                
                saveas(h,[num2str(data_number),'-',num2str(file_number),'-',num2str(ii),'_',num2str(frequency_range_max),'.fig'])
                
                close(h)
            end
        end
    end
end