fs=5000;
delta_band=4;
theta_band=[4 8];
alpha_band=[8 13];
beta_band=[13 30];
gamma_band=30;
delta_wave=lowpass(EEG,delta_band,fs,'Steepness',0.99,'StopbandAttenuation',100,'ImpulseResponse','iir');
theta_wave=bandpass(EEG,theta_band,fs,'Steepness',0.99);
alpha_wave=bandpass(EEG,alpha_band,fs,'Steepness',0.99);
beta_wave=bandpass(EEG,beta_band,fs,'Steepness',0.99);
gamma_wave=highpass(EEG,gamma_band,fs,'Steepness',0.99);
% delta_wave=EEG-theta_wave-alpha_wave-beta_wave-gamma_wave;
disp('done')
%%
time=linspace(0,time_all,size(EEG,1));
figure;
subplot(5,1,1);
plot(time,delta_wave);
axis tight
ylim([-150 150])
% axis off
subplot(5,1,2);
plot(time,theta_wave);
axis tight
ylim([-150 150])
% axis off
subplot(5,1,3);
plot(time,alpha_wave);
axis tight
ylim([-150 150])
% axis off
subplot(5,1,4);
plot(time,beta_wave);
axis tight
ylim([-150 150])
% axis off
subplot(5,1,5);
plot(time,gamma_wave);
axis tight
ylim([-150 150])
% axis off
%%
h=figure;

subplot(4,1,1);
time=linspace(0,time_all,size(EEG,1));
plot(time,EEG);
axis tight

subplot(4,1,2);
imagesc(trace_data);
colorbar
axis off

subplot(4,1,3);
time=linspace(0,time_all,size(dff_sum,2));
plot(time,dff_sum/max(dff_sum(:)));
axis tight

subplot(4,1,4);
time=linspace(0,time_all,size(EMG,1));
plot(time,EMG);
axis tight
ylim([-max(abs(EMG(:))) max(abs(EMG(:)))])

ha=get(gcf,'children');
colormap(ha(3),jet)
colormap(ha(4),jet)
%%
figure;
subplot(6,1,1);
plot(delta_wave);
axis tight
ylim([-150 150])
axis off
subplot(6,1,2);
plot(theta_wave);
axis tight
ylim([-150 150])
axis off
subplot(6,1,3);
plot(alpha_wave);
axis tight
ylim([-150 150])
axis off
subplot(6,1,4);
plot(beta_wave);
axis tight
ylim([-150 150])
axis off
subplot(6,1,5);
plot(gamma_wave);
axis tight
ylim([-150 150])
axis off
subplot(6,1,6);
plot(dff_sum);
axis tight
axis off