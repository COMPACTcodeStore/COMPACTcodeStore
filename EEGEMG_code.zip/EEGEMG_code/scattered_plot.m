%%
for data_number=2:4;
    for file_number=1:6;
        file_name=['data',num2str(data_number),'_',num2str(file_number)];
        load([file_name,'.mat']);
        load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
        dff_sum_resize=sum(deltaFdata')';
        EMG_resize=imresize(abs(EMG),[5000 1]);
        figure;
        plot(EMG_resize,dff_sum_resize,'.k');xlim([0 max(EMG_resize(:))+1]);ylim([0 max(dff_sum_resize(:))+1])
        drawnow
        title(file_name)
    end
end
%%
for data_number=2:4;
    dff_sum_resize_all=[];
    EMG_resize_all=[];
    for file_number=1:6;
        file_name=['data',num2str(data_number),'_',num2str(file_number)];
        load([file_name,'.mat']);
        load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
        dff_sum_resize=sum(deltaFdata')';
        EMG_resize=imresize(abs(EMG),[5000 1]);
        dff_sum_resize_all=[dff_sum_resize_all;dff_sum_resize];
        EMG_resize_all=[EMG_resize_all;EMG_resize];
    end
    [f,gof]=fit(EMG_resize_all,dff_sum_resize_all,'poly1');
    figure;
    plot(EMG_resize_all,dff_sum_resize_all,'.k');xlim([0 max(EMG_resize_all(:))+1]);ylim([0 max(dff_sum_resize_all(:))+1]);
    hold on;
    plot(f);
    hold off
    title([num2str(data_number),',rsquare:',num2str(gof.rsquare)])
    drawnow
end
%%
data_number=3;
file_number=1;
seq_number=2;
frequency_range_min=8;
frequency_range_max=13;

frequency_resolution=0.1;
frequency_number=1/frequency_resolution*5e3-1;


file_name=['data',num2str(data_number),'_',num2str(file_number)];
load([file_name,'.mat']);
load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);

s_EEG=spectrogram(EEG,2048,193,frequency_number,5e3);
s_EEG=imresize(s_EEG,[(frequency_number+1)/2 5000]);

dff_sum=sum(deltaFdata');

data1=sum(abs(s_EEG((frequency_range_min/frequency_resolution):(frequency_range_max/frequency_resolution),((seq_number-1)*1000)+1:(seq_number*1000))));
figure;
plot(data1,dff_sum(((seq_number-1)*1000)+1:(seq_number*1000)),'.k')
%%
rolling_window=371;
for data_number=2:4;
    dff_sum_resize_all=[];
    EMG_resize_all=[];
    for file_number=1:6;
        file_name=['data',num2str(data_number),'_',num2str(file_number)];
        load([file_name,'.mat']);
        load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
        EMG_p2p=[];
        for ii=1:size(deltaFdata,1)
            N=371.2*(ii-1);
            EMG_seg=EMG((round(N)+1):(round(N)+rolling_window));
            EMG_p2p=[EMG_p2p;max(EMG_seg(:))-min(EMG_seg(:))];
        end
        dff_sum_resize=sum(deltaFdata')';
        dff_sum_resize_all=[dff_sum_resize_all;dff_sum_resize];
        EMG_resize_all=[EMG_resize_all;EMG_p2p];
    end
    %     [f,gof]=fit(EMG_resize_all,dff_sum_resize_all,'poly1');
    %     figure;
    %     plot(EMG_resize_all,dff_sum_resize_all,'.k');
    %     %     xlim([0 max(EMG_resize_all(:))+1]);
    %     xlim([0 4000]);
    %     ylim([0 max(dff_sum_resize_all(:))+1]);
    %     hold on;
    %     plot(f);
    %     hold off
    %     title([num2str(data_number),'rsquar:',num2str(gof.rsquare)])
    %     drawnow
    EMG_resize_all(dff_sum_resize_all <0) = [];
    dff_sum_resize_all(dff_sum_resize_all <0) = [];
    EMG_resize_all=(EMG_resize_all-min(EMG_resize_all(:)))/(max(EMG_resize_all(:))-min(EMG_resize_all(:)));
    dff_sum_resize_all=(dff_sum_resize_all-min(dff_sum_resize_all(:)))/(max(dff_sum_resize_all(:))-min(dff_sum_resize_all(:)));
    [f,gof]=fit(EMG_resize_all,dff_sum_resize_all,'poly1');
    figure;
    plot(EMG_resize_all,dff_sum_resize_all,'.k');
    xlim([0 1]);
    ylim([0 1]);
    hold on;
    plot(f);
    hold off
    title([num2str(data_number),' rsquar:',num2str(gof.rsquare)])
end
%%
rolling_window=500;
for data_number=2:4;
    dff_sum_resize_all=[];
    EMG_resize_all=[];
    for file_number=1:6;
        file_name=['data',num2str(data_number),'_',num2str(file_number)];
        load([file_name,'.mat']);
        load(['dff',num2str(data_number),'_',num2str(file_number),'.mat']);
        EMG_p2p=[];
        for ii=1:size(deltaFdata,1)
            N=371.2*(ii-1);
            if round(N)+rolling_window>size(EMG,1)
                EMG_seg=EMG((round(N)+1):size(EMG,1));
                EMG_p2p=[EMG_p2p;max(EMG_seg(:))-min(EMG_seg(:))];
            else
                EMG_seg=EMG((round(N)+1):(round(N)+rolling_window));
                EMG_p2p=[EMG_p2p;max(EMG_seg(:))-min(EMG_seg(:))];
            end
            
        end
        %         dff_sum_resize=sum(deltaFdata')';
        dff_sum_resize=deltaFdata;
        dff_sum_resize_all=[dff_sum_resize_all;dff_sum_resize];
        EMG_resize_all=[EMG_resize_all;EMG_p2p];
    end
    figure;
    for ii=1:1
        plot(EMG_resize_all,dff_sum_resize_all(:,ii),'.');xlim([0 max(EMG_resize_all(:))+1]);ylim([0 max(dff_sum_resize_all(:))+1]);
        hold on;
    end
    hold off
    title([num2str(data_number)])
    drawnow
end